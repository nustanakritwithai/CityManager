[CmdletBinding()]
param([ValidateSet('Plan','Apply')][string]$Mode='Plan')
$ErrorActionPreference='Stop'
$Root='C:\Users\Administrator\Documents\Codex\2026-10-26\task-8\market-server-release-6269011'
$Startup='C:\ProgramData\CityManagerMarket\startup.ps1'
$Node='C:\Program Files\nodejs\node.exe'
$TaskName='CityManager-Market-Boot'
$Bundle=$PSScriptRoot
function HashFile([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function RunNode([string[]]$Arguments){
 $previous=$ErrorActionPreference
 try{$ErrorActionPreference='Continue';$output=@(& $Node @Arguments 2>&1);$code=$LASTEXITCODE}finally{$ErrorActionPreference=$previous}
 if($code -ne 0){$detail='validation-failed';try{$r=($output -join "`n")|ConvertFrom-Json;if($r.validation -match '^[a-z-]+$'){$detail=$r.validation}}catch{};throw ('Node check stopped: '+$detail)}
 return ($output -join "`n")
}
function Health{if((Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4317/health' -TimeoutSec 3).StatusCode -ne 200){throw 'API health failed.'}}
function Runtime{
 $listeners=@(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue)
 $ids=@($listeners|Select-Object -ExpandProperty OwningProcess -Unique)
 if($ids.Count -ne 1 -or @($listeners|Where-Object {$_.LocalAddress -notin @('127.0.0.1','::1')}).Count){throw 'Expected sole loopback API process.'}
 $p=Get-CimInstance Win32_Process -Filter "ProcessId=$($ids[0])"
 if($p.ExecutablePath -ne $Node){throw 'Unexpected API executable.'}
 $exe='(?:'+[regex]::Escape($Node)+'|node(?:\.exe)?)'
 $entry='(?:'+[regex]::Escape((Join-Path $Root 'src\server.js'))+'|(?:\.\\)?src\\server\.js)'
 if($p.CommandLine.Replace('/','\') -notmatch ('^\s*"?'+$exe+'"?\s+"?'+$entry+'"?\s*$')){throw 'Unverified API entry/arguments.'}
 return @{Pid=[int]$p.ProcessId;CreatedTicks=([datetime]$p.CreationDate).ToUniversalTime().Ticks;CommandHash=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($p.CommandLine))).Replace('-',''));RuntimeDirectoryVerified=$false}
}
function TaskContract{
 $t=@(Get-ScheduledTask -TaskName $TaskName)
 if($t.Count -ne 1 -or @($t[0].Actions).Count -ne 1 -or $t[0].TaskPath -ne '\'){throw 'Unexpected startup task count.'}
 $a=$t[0].Actions[0]
 $pattern='^\s*(?:(?:-NoProfile|-NoLogo|-NonInteractive)\s+|-ExecutionPolicy\s+(?:Bypass|RemoteSigned|AllSigned|Restricted|Unrestricted)\s+|-WindowStyle\s+(?:Hidden|Normal|Minimized|Maximized)\s+)*-File\s+"?'+[regex]::Escape($Startup)+'"?\s*$'
 if([IO.Path]::GetFileName($a.Execute) -notin @('powershell.exe','pwsh.exe') -or $a.Arguments -notmatch $pattern){throw 'Unexpected task action.'}
 if((HashFile $Startup) -ne $script:StartupHash){throw 'Startup integrity contract drift.'}
 return @{Path=$t[0].TaskPath;Action=($a.Execute+' '+$a.Arguments)}
}
function CheckTask($Expected){$now=TaskContract;if($now.Path -ne $Expected.Path -or $now.Action -ne $Expected.Action){throw 'Startup task drift.'}}
function StopApi($Expected,$Task){
 CheckTask $Task;$now=Runtime
 if($now.Pid -ne $Expected.Pid -or $now.CreatedTicks -ne $Expected.CreatedTicks -or $now.CommandHash -ne $Expected.CommandHash){throw 'API identity drift before stop.'}
 Stop-ScheduledTask -TaskName $TaskName -TaskPath $Task.Path -ErrorAction SilentlyContinue
 Start-Sleep -Milliseconds 300
 $p=Get-CimInstance Win32_Process -Filter "ProcessId=$($Expected.Pid)"
 if($p){if(([datetime]$p.CreationDate).ToUniversalTime().Ticks -ne $Expected.CreatedTicks){throw 'PID reused; refused stop.'};Stop-Process -Id $Expected.Pid}
 for($i=0;$i -lt 30;$i++){if(-not (Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue) -and (Get-ScheduledTask -TaskName $TaskName -TaskPath $Task.Path).State -ne 'Running'){return};Start-Sleep -Milliseconds 200}
 throw 'Verified API did not stop.'
}
function StartApi($Task){
 CheckTask $Task
 if(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue){throw 'Port occupied; no duplicate startup.'}
 if((Get-ScheduledTask -TaskName $TaskName -TaskPath $Task.Path).State -eq 'Running'){Stop-ScheduledTask -TaskName $TaskName -TaskPath $Task.Path;for($i=0;$i -lt 20;$i++){if((Get-ScheduledTask -TaskName $TaskName -TaskPath $Task.Path).State -ne 'Running'){break};Start-Sleep -Milliseconds 250};if((Get-ScheduledTask -TaskName $TaskName -TaskPath $Task.Path).State -eq 'Running'){throw 'Task did not quiesce.'}}
 if(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue){throw 'Port became occupied; refused startup.'}
 $started=(Get-Date).ToUniversalTime().Ticks;$script:StartedAt=$started
 Start-ScheduledTask -TaskName $TaskName -TaskPath $Task.Path
 for($i=0;$i -lt 60;$i++){try{Health;$p=Runtime;if($p.CreatedTicks -lt $started){throw 'Unexpected preexisting process.'};return}catch{Start-Sleep -Seconds 1}}
 throw 'API readiness failed; inspect startup-status locally.'
}
function AtomicWrite([string]$Source,[string]$Destination,[string]$Expected){
 $temp=$Destination+'.management-'+[Guid]::NewGuid().ToString('N')+'.tmp'
 Copy-Item -LiteralPath $Source -Destination $temp
 if((HashFile $temp) -ne $Expected){throw 'Atomic staged hash mismatch.'}
 if(Test-Path -LiteralPath $Destination){$backup=$Destination+'.management-replaced-'+[Guid]::NewGuid().ToString('N')+'.bak';if(Test-Path -LiteralPath $backup){throw 'Unexpected backup collision.'};[IO.File]::Replace($temp,$Destination,$backup)}else{[IO.File]::Move($temp,$Destination)}
 if((HashFile $Destination) -ne $Expected){throw 'Atomic destination mismatch.'}
}
function TestAtomic([string]$Parent){$dir=Join-Path $Parent ('management-atomic-test-'+[Guid]::NewGuid().ToString('N'));[void](New-Item -ItemType Directory -Path $dir);$a=Join-Path $dir 'a';$b=Join-Path $dir 'b';$dst=Join-Path $dir 'destination';[IO.File]::WriteAllText($a,'old');[IO.File]::WriteAllText($b,'new');AtomicWrite $a $dst (HashFile $a);AtomicWrite $b $dst (HashFile $b);AtomicWrite $a $dst (HashFile $a)}
$manifest=Get-Content -LiteralPath (Join-Path $Bundle 'bundle-manifest.json') -Raw|ConvertFrom-Json
$roster=@('README.md','Update-PagesSession.ps1','patch-session.mjs')|Sort-Object
if($manifest.version -ne 1 -or (($manifest.files.PSObject.Properties.Name|Sort-Object)-join ',') -ne ($roster-join ',')){throw 'Unexpected bundle roster.'}
foreach($p in $manifest.files.PSObject.Properties){if($p.Value -notmatch '^[a-f0-9]{64}$' -or (HashFile (Join-Path $Bundle $p.Name)) -ne $p.Value){throw 'Bundle hash mismatch.'}}
$module=Join-Path $Root 'src'
$installed=Join-Path $Root 'src\city-saves\pages-session-install-manifest.json'
if(Test-Path -LiteralPath $installed){
 $prior=Get-Content -LiteralPath $installed -Raw|ConvertFrom-Json
 if($prior.version -ne 1 -or $prior.bundleHash -ne (HashFile (Join-Path $Bundle 'bundle-manifest.json')) -or (HashFile $Startup) -ne $prior.startupHash){throw 'Unknown management installation/drift.'}
 foreach($name in @('pages-auth.js')){if((HashFile (Join-Path $module $name)) -ne $prior.modules.PSObject.Properties[$name].Value){throw 'Installed module drift.'}}
 $script:StartupHash=$prior.startupHash;[void](TaskContract);[void](Runtime);Health
 Write-Output 'PAGES_SESSION_24H_ALREADY_RECORDED: auth/startup hashes and runtime healthy; no update performed.';return
}
$stage=Join-Path (Split-Path $Root -Parent) ('city-pages-session-'+[Guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $stage)
$candidate=Join-Path $stage 'startup.ps1'
$patch=RunNode -Arguments @((Join-Path $Bundle 'patch-session.mjs'),$Root,$Startup,$stage)|ConvertFrom-Json
$script:StartupHash=$patch.originalHash
$task=TaskContract;$runtime=Runtime;Health
$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($candidate,[ref]$tokens,[ref]$errors);if($errors.Count){throw 'Candidate startup parse failed.'}
foreach($name in @('pages-auth.js')){[void](RunNode -Arguments @('--check',(Join-Path $stage $name)))}
Write-Output 'TTL=86400; only newly issued Pages bearer tokens; no DB/cookie/permission-scope changes.'
if($Mode -eq 'Plan'){Write-Output 'PAGES_SESSION_24H_PLAN_OK: no live source/schema/process changes.';return}
TestAtomic $module;TestAtomic (Split-Path $Startup -Parent)
$backup=Join-Path $stage 'backup';[void](New-Item -ItemType Directory -Path $backup)
foreach($name in @('pages-auth.js')){Copy-Item -LiteralPath (Join-Path $module $name) -Destination (Join-Path $backup $name);if((HashFile (Join-Path $backup $name)) -ne $patch.originalModules.PSObject.Properties[$name].Value){throw 'Module backup hash mismatch.'}}
Copy-Item -LiteralPath $Startup -Destination (Join-Path $backup 'startup.ps1');if((HashFile (Join-Path $backup 'startup.ps1')) -ne $patch.originalHash){throw 'Startup backup mismatch.'}
$stopAttempted=$false;$changed=$false
try{
 CheckTask $task
 foreach($name in @('pages-auth.js')){if((HashFile (Join-Path $module $name)) -ne $patch.originalModules.PSObject.Properties[$name].Value){throw 'Module drift before stop.'}}
 if((HashFile (Join-Path $stage 'pages-auth.js')) -ne $patch.candidateModules.'pages-auth.js'){throw 'Auth candidate drift.'}
 if((HashFile $candidate) -ne $patch.candidateHash){throw 'Startup candidate drift.'}
 $stopAttempted=$true;StopApi $runtime $task
 $changed=$true
 foreach($name in @('pages-auth.js')){AtomicWrite (Join-Path $stage $name) (Join-Path $module $name) $patch.candidateModules.PSObject.Properties[$name].Value}
 AtomicWrite $candidate $Startup $patch.candidateHash
 $script:StartupHash=$patch.candidateHash
 StartApi $task
 try{[void](Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4317/v1/city-save' -TimeoutSec 5);throw 'Unauthenticated save accepted.'}catch{if(-not $_.Exception.Response -or [int]$_.Exception.Response.StatusCode -ne 401){throw 'Save401 not verified.'}}
 @{version=1;bundleHash=(HashFile (Join-Path $Bundle 'bundle-manifest.json'));startupHash=$patch.candidateHash;modules=$patch.candidateModules;backup=$backup;runtimeDirectoryVerified=$false}|ConvertTo-Json|Set-Content -LiteralPath $installed -Encoding UTF8
 Write-Output ('PAGES_SESSION_24H_INSTALLED health200 save401; reconnect to obtain a new token. No existing tokens/data changed. Backup='+$backup)
}catch{
 $reason=$_.Exception.Message
 if($stopAttempted -and -not $changed){try{if(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue){Health;[void](Runtime)}else{StartApi $task};Write-Warning 'Backend files were unchanged; original API is healthy.'}catch{Write-Warning 'Original API restart requires manual review.'}}
 elseif($stopAttempted){try{
  $observed=HashFile $Startup;if($observed -ne $patch.originalHash -and $observed -ne $patch.candidateHash){throw 'External startup change; automatic rollback refused.'};$script:StartupHash=$observed;CheckTask $task
  foreach($name in @('pages-auth.js')){$h=HashFile (Join-Path $module $name);if($h -ne $patch.originalModules.PSObject.Properties[$name].Value -and $h -ne $patch.candidateModules.PSObject.Properties[$name].Value){throw 'External module change; rollback refused.'};if((HashFile (Join-Path $backup $name)) -ne $patch.originalModules.PSObject.Properties[$name].Value){throw 'Backup drift.'}}
  if((HashFile (Join-Path $backup 'startup.ps1')) -ne $patch.originalHash){throw 'Startup backup drift.'}
  if(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue){$running=Runtime;if(-not $script:StartedAt -or $running.CreatedTicks -lt $script:StartedAt){throw 'Unexpected process after patch; refused rollback stop.'};StopApi $running $task}else{CheckTask $task;Stop-ScheduledTask -TaskName $TaskName -TaskPath $task.Path -ErrorAction SilentlyContinue}
  for($i=0;$i -lt 20;$i++){if((Get-ScheduledTask -TaskName $TaskName -TaskPath $task.Path).State -ne 'Running'){break};Start-Sleep -Milliseconds 250}
  if((Get-ScheduledTask -TaskName $TaskName -TaskPath $task.Path).State -eq 'Running' -or (Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue)){throw 'Writer not quiesced; refused rollback.'}
  # Restore exact prior authentication source and integrity guard; no token rows are rewritten.
  foreach($name in @('pages-auth.js')){if((HashFile (Join-Path $module $name)) -ne $patch.originalModules.PSObject.Properties[$name].Value){AtomicWrite (Join-Path $backup $name) (Join-Path $module $name) $patch.originalModules.PSObject.Properties[$name].Value}}
  if((HashFile $Startup) -ne $patch.originalHash){AtomicWrite (Join-Path $backup 'startup.ps1') $Startup $patch.originalHash}
  $script:StartupHash=$patch.originalHash;StartApi $task
  Write-Warning 'Previous authentication source/guard restored; token rows and all city data retained.'
 }catch{Write-Warning ('Authentication source rollback failed/refused; API may remain stopped. Preserve all data and backups for recovery. Backup='+$backup)}}
 throw ('Pages session update stopped: '+$reason+'. No save/account purge performed.')
}
