import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import {fileURLToPath} from 'node:url';
export const hash=b=>createHash('sha256').update(b).digest('hex');
const known={'src\\startup-guard.js':'dec068bc47b2ce02162eb39a1f3948c82f2fd143ba4e02ab0e1e9ffea26d5b90','src\\owner-pin-auth.js':'e32ee986286fe6684f8e07a05fa0efc1c3b520ae9dabb02a75e03e2911bb6078','src\\city-saves\\service.mjs':'103a44ee505bc938f5a69994baaab5f2cd4372b7cf567b5bdc31163fd2f217d1','src\\city-saves\\pg-store.mjs':'dede1d6560cc6d6a2468913e8dc5fffc6c369fc0981337e7c98f26e1466256b9','src\\city-saves\\router.mjs':'2a54010ec3a984c61d9005d19a3830c44abf2e901fcf4dfca385a88d177f90e6'};
function text(bytes){const s=bytes.toString('utf8');if(!Buffer.from(s).equals(bytes))throw Error('source-encoding');return s;}
export function patchTTL(bytes){
 const s=text(bytes);
 const auth=s.slice(s.indexOf('export async function authenticatePagesBearer'),s.indexOf('// Forwarded'));
 if(!/s\.revoked_at\s+IS\s+NULL/i.test(auth)||!/s\.expires_at\s*>\s*now\(\)/i.test(auth)||!/t\.revoked_at\s+IS\s+NULL/i.test(auth)||!/t\.expires_at\s*>\s*now\(\)/i.test(auth))throw Error('parent-token-revocation-contract');
 const starts=[...s.matchAll(/router\.post\('\/exchange',/g)];if(starts.length!==1)throw Error('exchange-anchor-count');
 const start=starts[0].index,end=s.indexOf("router.post('",start+starts[0][0].length);if(end<0)throw Error('exchange-end-anchor');
 const patterns=[[/Date\.now\(\)\+15\*60000/g,'Date.now()+86400*1000'],[/expires_in:900\b/g,'expires_in:86400']];let candidate=s;
 for(const [pattern,replacement]of patterns){const matches=[...s.matchAll(pattern)];if(matches.length!==1||matches[0].index<start||matches[0].index>=end)throw Error('ttl-anchor-count-or-scope');candidate=candidate.replace(pattern,replacement);}
 return Buffer.from(candidate);
}
export function patchGuard(bytes,expected,nextHash){
 const s=text(bytes),matches=[...s.matchAll(/\$guard\s*=\s*@\{([^}]*?)\}/g)];if(matches.length!==1)throw Error('guard-assignment-count');const m=matches[0];
 const re=/(['"])(src\\[^'"\r\n]+)\1\s*=\s*(['"])([a-fA-F0-9]{64})\3/g,entries=[...m[1].matchAll(re)],seen=new Set();
 if(entries.length!==7||Object.keys(expected).length!==7||m[1].replace(re,'').replace(/[;\s]/g,'')!=='')throw Error('guard-shape');
 for(const e of entries){if(seen.has(e[2])||expected[e[2]]!==e[4].toLowerCase())throw Error('guard-entry-drift');seen.add(e[2]);}
 const body=m[1].replace(re,(whole,q,key,q2,value)=>key==='src\\pages-auth.js'?whole.replace(value,nextHash.toUpperCase()):whole);const at=m.index+m[0].indexOf('{')+1;return Buffer.from(s.slice(0,at)+body+s.slice(at+m[1].length));
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{
 const [root,startup,stage]=process.argv.slice(2);const read=n=>JSON.parse(fs.readFileSync(path.join(root,'src/city-saves',n),'utf8').replace(/^\uFEFF/,''));
 const base=read('install-manifest.json'),management=read('management-install-manifest.json'),inbox=read('inbox-preservation-install-manifest.json');
 if(base.version!==1||base.startupOriginalHash!=='c7139d654e3ed106680fe2db1b8701f3a2cfd08ca906e541d7a16c6fce176ee3'||management.version!==1||management.bundleHash!=='669cdd883b24c64b73b69c5ae3a4f77420d642eb05ca1d770587d66664862d57'||inbox.version!==1||inbox.bundleHash!=='990a78d9760477a1f9b7ed096cc595d1b399461414b422fae0a566e875d75ca9')throw Error('installed-baseline-unrecognized');
 const original=fs.readFileSync(startup);if(hash(original)!==inbox.startupHash)throw Error('startup-drift');const expected={...known};
 for(const name of ['server.js','pages-auth.js']){const h=base.installed['src/'+name];if(!/^[a-f0-9]{64}$/.test(h))throw Error('installed-source-hash');expected['src\\'+name]=h;}
 for(const [name,h]of Object.entries(expected))if(hash(fs.readFileSync(path.join(root,...name.split('\\'))))!==h)throw Error('guarded-source-drift');
 const before=fs.readFileSync(path.join(root,'src/pages-auth.js')),after=patchTTL(before),guard=patchGuard(original,expected,hash(after));
 fs.writeFileSync(path.join(stage,'pages-auth.js'),after,{flag:'wx'});fs.writeFileSync(path.join(stage,'startup.ps1'),guard,{flag:'wx'});
 console.log(JSON.stringify({originalHash:hash(original),candidateHash:hash(guard),originalModules:{'pages-auth.js':hash(before)},candidateModules:{'pages-auth.js':hash(after)},ttlSeconds:86400,existingTokensChanged:false}));
 }catch(e){console.error(JSON.stringify({ok:false,validation:e.message}));process.exitCode=1;}
}
