/** User-run only. Reads existing DB config locally, never prints credentials or SQL data. */
import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';
const [rootArg]=process.argv.slice(2);const mode='plan';let pool;
const digest=s=>createHash('sha256').update(s).digest('hex');
const tables=['city_server_snapshots','city_server_requests','city_server_archives','city_server_archive_sources','city_server_installation'];
async function fingerprint(c){
 const columns=(await c.query(`SELECT table_name,column_name,data_type,is_nullable,column_default FROM information_schema.columns WHERE table_schema='public' AND table_name=ANY($1::text[]) ORDER BY table_name,ordinal_position`,[tables])).rows;
 const constraints=(await c.query(`SELECT rel.relname AS table_name,con.conname,pg_get_constraintdef(con.oid) AS definition FROM pg_constraint con JOIN pg_class rel ON rel.oid=con.conrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE ns.nspname='public' AND rel.relname=ANY($1::text[]) ORDER BY rel.relname,con.conname`,[tables])).rows;
 const indexes=(await c.query(`SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='public' AND tablename=ANY($1::text[]) ORDER BY tablename,indexname`,[tables])).rows;
 const triggers=(await c.query(`SELECT rel.relname AS table_name,pg_get_triggerdef(t.oid) AS definition FROM pg_trigger t JOIN pg_class rel ON rel.oid=t.tgrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE NOT t.tgisinternal AND ns.nspname='public' AND rel.relname=ANY($1::text[]) ORDER BY rel.relname,t.tgname`,[tables])).rows;
 const functions=(await c.query(`SELECT pg_get_functiondef(p.oid) AS definition FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='city_server_immutable' ORDER BY p.oid`)).rows;
 return digest(JSON.stringify({columns,constraints,indexes,triggers,functions}));
}
try{
 if(!rootArg)throw Error('invalid-mode');
 if(!process.env.DATABASE_URL){const raw=fs.readFileSync('C:\\ProgramData\\CityManagerMarket\\DATABASE_URL','utf8').trim();if(!raw||raw.includes('\n')||raw.includes('\r'))throw Error('database-config-format');process.env.DATABASE_URL=raw;}
 const u=new URL(process.env.DATABASE_URL);if(!['postgres:','postgresql:'].includes(u.protocol)||!['127.0.0.1','localhost'].includes(u.hostname)||u.port!=='55432'||u.pathname!=='/cm_market_sandbox')throw Error('unexpected-database-target');
 const root=path.resolve(rootArg),module=await import(pathToFileURL(path.join(root,'src/db.js')).href);pool=module.pool;if(!pool||typeof module.tx!=='function')throw Error('existing-db-contract-missing');
 const migrationHash='c17c6c780df6204b7ad50baa3f28b9340dc188645fcf242977fadae245721af3';
 const inspect=async c=>{
  const identity=(await c.query('SELECT current_database() AS database,current_schema() AS schema,host(inet_server_addr()) AS address,inet_server_port() AS port')).rows[0];if(identity.database!=='cm_market_sandbox'||identity.schema!=='public'||!['127.0.0.1','::1'].includes(identity.address)||identity.port!==55432)throw Error('unexpected-db-schema');
  const present=(await c.query(`SELECT relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname=ANY($1::text[])`,[tables])).rows.map(r=>r.relname);
  const functionPresent=(await c.query(`SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='city_server_immutable'`)).rowCount;
  if(!present.length&&!functionPresent)return 'absent';
  if(present.length!==tables.length||!functionPresent)throw Error('partial-or-unknown-save-schema');
  const records=(await c.query('SELECT version,migration_hash,schema_hash FROM public.city_server_installation')).rows;
  if(records.length!==1||records[0].version!==1||records[0].migration_hash!==migrationHash||records[0].schema_hash!==await fingerprint(c))throw Error('save-schema-version-mismatch');return 'installed';
 };
 const c=await pool.connect();try{console.log(JSON.stringify({ok:true,database:'cm_market_sandbox',schema:await inspect(c),migrationHash}));}finally{c.release();}
}catch(error){console.error(JSON.stringify({ok:false,reason:'Database preflight/migration stopped; no credentials printed',code:typeof error?.code==='string'?error.code:'validation-failed',validation:/^[a-z][a-z-]+$/.test(error?.message??'')?error.message:undefined}));process.exitCode=1;}finally{if(pool)await pool.end();}
