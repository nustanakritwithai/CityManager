CityManager existing-login city-save: PLAN ONLY

Run Plan-CitySave.ps1 from an elevated Windows PowerShell on the existing VPS.
The script validates the exact source hashes already backed up by the user,
checks the current Node process/startup task, health and Pages CORS headers,
stages proposed source copies into a new TEMP report folder, and runs read-only
schema checks through the existing db.js pool. It does not alter live source,
create tables/accounts, restart/stop processes, change access policies or write
player saves. There is no Apply switch, migration SQL or restart implementation
in this package.

The database helper may read the existing protected DATABASE_URL file LOCALLY
only if the existing process environment lacks that setting. It never prints
its value. It validates the loopback database target and does not persist the
setting. Do not upload configuration, tokens, cookies or source files from the
report folder. Return only PLAN_OK JSON (preflight-report.json) or the error.

This package passed Node syntax/mock-patch tests. Windows PowerShell and actual
PostgreSQL execution have not yet been tested; this Plan supplies that evidence
without applying the proposed change. Stop if any check fails; don't bypass it.

Plan v2 accepts only the observed bare relative src/server.js argument or the
exact approved absolute entrypoint, with no additional arguments/flags. For a
relative entry it returns PLAN_REVIEW_REQUIRED even if the startup script has
a matching static working-directory declaration. CIM does not establish the
running process working directory. Such a report does NOT permit Apply or
process termination. Return the JSON report for review; no additional changes
are made.

Plan v3 fixes PostgreSQL inet address rendering: host(inet_server_addr())
returns the exact address without a CIDR display mask. Only 127.0.0.1 or ::1
at port55432 in public/cm_market_sandbox remain accepted. No schemas changed.
