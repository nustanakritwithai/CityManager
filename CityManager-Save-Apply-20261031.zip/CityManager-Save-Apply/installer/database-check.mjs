/** User-run only. Reads existing DB config locally, never prints credentials or SQL data. */
import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';
const [mode,rootArg,bundleArg,expectedMigrationHash]=process.argv.slice(2);let pool;
const digest=s=>createHash('sha256').update(s).digest('hex');
const tables=['city_server_snapshots','city_server_requests','city_server_archives','city_server_archive_sources','city_server_installation'];
async function fingerprint(c){
 const columns=(await c.query(`SELECT table_name,column_name,data_type,is_nullable,column_default FROM information_schema.columns WHERE table_schema='public' AND table_name=ANY($1::text[]) ORDER BY table_name,ordinal_position`,[tables])).rows;
 const constraints=(await c.query(`SELECT rel.relname AS table_name,con.conname,pg_get_constraintdef(con.oid) AS definition FROM pg_constraint con JOIN pg_class rel ON rel.oid=con.conrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE ns.nspname='public' AND rel.relname=ANY($1::text[]) ORDER BY rel.relname,con.conname`,[tables])).rows;
 const indexes=(await c.query(`SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='public' AND tablename=ANY($1::text[]) ORDER BY tablename,indexname`,[tables])).rows;
 const triggers=(await c.query(`SELECT rel.relname AS table_name,pg_get_triggerdef(t.oid) AS definition FROM pg_trigger t JOIN pg_class rel ON rel.oid=t.tgrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE NOT t.tgisinternal AND ns.nspname='public' AND rel.relname=ANY($1::text[]) ORDER BY rel.relname,t.tgname`,[tables])).rows;
 const functions=(await c.query(`SELECT pg_get_functiondef(p.oid) AS definition FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='city_server_immutable' ORDER BY p.oid`)).rows;
 return digest(JSON.stringify({columns,constraints,indexes,triggers,functions}));
}
try{
 if(!['plan','validate','apply'].includes(mode)||!rootArg||!bundleArg||!/^[a-f0-9]{64}$/.test(expectedMigrationHash??''))throw Error('invalid-mode');
 if(!process.env.DATABASE_URL){const raw=fs.readFileSync('C:\\ProgramData\\CityManagerMarket\\DATABASE_URL','utf8').trim();if(!raw||raw.includes('\n')||raw.includes('\r'))throw Error('database-config-format');process.env.DATABASE_URL=raw;}
 const u=new URL(process.env.DATABASE_URL);if(!['postgres:','postgresql:'].includes(u.protocol)||!['127.0.0.1','localhost'].includes(u.hostname)||u.port!=='55432'||u.pathname!=='/cm_market_sandbox')throw Error('unexpected-database-target');
 const root=path.resolve(rootArg),bundle=path.resolve(bundleArg),module=await import(pathToFileURL(path.join(root,'src/db.js')).href);pool=module.pool;if(!pool||typeof module.tx!=='function')throw Error('existing-db-contract-missing');
 const migration=fs.readFileSync(path.join(bundle,'migration.sql'),'utf8'),migrationHash=digest(migration);if(migrationHash!==expectedMigrationHash)throw Error('migration-payload-hash-mismatch');
 const inspect=async c=>{
  const identity=(await c.query('SELECT current_database() AS database,current_schema() AS schema,host(inet_server_addr()) AS address,inet_server_port() AS port')).rows[0];if(identity.database!=='cm_market_sandbox'||identity.schema!=='public'||!['127.0.0.1','::1'].includes(identity.address)||identity.port!==55432)throw Error('unexpected-db-schema');
  const present=(await c.query(`SELECT relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname=ANY($1::text[])`,[tables])).rows.map(r=>r.relname);
  const functionPresent=(await c.query(`SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='city_server_immutable'`)).rowCount;
  if(!present.length&&!functionPresent)return 'absent';
  if(present.length!==tables.length||!functionPresent)throw Error('partial-or-unknown-save-schema');
  const records=(await c.query('SELECT version,migration_hash,schema_hash FROM public.city_server_installation')).rows;
  if(records.length!==1||records[0].version!==1||records[0].migration_hash!==migrationHash||records[0].schema_hash!==await fingerprint(c))throw Error('save-schema-version-mismatch');return 'installed';
 };
 if(mode==='plan'){const c=await pool.connect();try{console.log(JSON.stringify({ok:true,database:'cm_market_sandbox',schema:await inspect(c),migrationHash}));}finally{c.release();}}
 else if(mode==='validate'){
  const {createServerCityService}=await import(pathToFileURL(path.join(bundle,'service.mjs')).href);
  const {createServerCityPgStore}=await import(pathToFileURL(path.join(bundle,'pg-store.mjs')).href);
  const initial=await pool.connect();try{if(await inspect(initial)!=='absent')throw Error('validation-requires-absent-schema');}finally{initial.release();}
  const sentinel=Object.assign(Error('city-save-fixture-rollback'),{fixtureRollback:true});let reached=false;
  try{await module.tx(async c=>{
   // TEMP objects only. Never query or lock real accounts/player saves.
   await c.query('CREATE TEMP TABLE accounts(id uuid PRIMARY KEY) ON COMMIT DROP');
   await c.query('SET LOCAL search_path = pg_temp, pg_catalog');
   const fixtureSql=migration.replace(/^BEGIN;$/m,'').replace(/^COMMIT;$/m,'').replace(/CREATE TABLE /g,'CREATE TEMP TABLE ').replace(/CREATE FUNCTION city_server_immutable/g,'CREATE FUNCTION pg_temp.city_server_immutable').replace(/EXECUTE FUNCTION city_server_immutable/g,'EXECUTE FUNCTION pg_temp.city_server_immutable');
   await c.query(fixtureSql);
   const owner='11111111-1111-4111-8111-111111111111',cityId='22222222-2222-4222-8222-222222222222';
   await c.query('INSERT INTO pg_temp.accounts(id) VALUES($1)',[owner]);
   const service=createServerCityService(createServerCityPgStore({pool:{query:(...a)=>c.query(...a)},tx:fn=>fn(c)}));
   const body={action:'create',cityId,raw:'{"version":23,"tick":1}',metadata:{name:'Isolated rollback fixture',population:0,tick:1}};
   const requestId='33333333-3333-4333-8333-333333333333';
   const first=await service.mutate(owner,requestId,body),replay=await service.mutate(owner,requestId,body);
   if(first.revision!==1||replay.raw!==body.raw||replay.revision!==1)throw Error('fixture-idempotency-failed');
   await service.mutate(owner,'44444444-4444-4444-8444-444444444444',{action:'save',cityId,expectedRevision:1,raw:body.raw,metadata:body.metadata});
   let stale=false;try{await service.mutate(owner,'55555555-5555-4555-8555-555555555555',{action:'save',cityId,expectedRevision:1,raw:body.raw,metadata:body.metadata});}catch(e){if(e.status!==409)throw e;stale=true;}
   if(!stale||(await service.read(owner)).revision!==2)throw Error('fixture-cas-failed');
   reached=true;throw sentinel;
  });}catch(e){if(e!==sentinel)throw e;}
  if(!reached)throw Error('fixture-did-not-complete');
  const final=await pool.connect();try{if(await inspect(final)!=='absent')throw Error('fixture-public-schema-changed');}finally{final.release();}
  console.log(JSON.stringify({ok:true,validation:'temporary-transaction-rolled-back',playerDataTouched:false,publicSchema:'absent'}));
 }
 else {
  const status=await module.tx(async c=>{
   await c.query("SELECT pg_advisory_xact_lock(hashtext('CityManager-server-save-install-v1'))");const state=await inspect(c);if(state==='installed')return state;
   if((migration.match(/^BEGIN;$/gm)||[]).length!==1||(migration.match(/^COMMIT;$/gm)||[]).length!==1)throw Error('migration-wrapper-invalid');
   await c.query(migration.replace(/^BEGIN;$/m,'').replace(/^COMMIT;$/m,''));
   await c.query('CREATE TABLE public.city_server_installation(version integer PRIMARY KEY,migration_hash text NOT NULL,schema_hash text NOT NULL,applied_at timestamptz NOT NULL DEFAULT now())');
   await c.query('INSERT INTO public.city_server_installation(version,migration_hash,schema_hash) VALUES(1,$1,$2)',[migrationHash,await fingerprint(c)]);return 'installed';
  });console.log(JSON.stringify({ok:true,schema:status,migrationHash}));
 }
}catch(error){console.error(JSON.stringify({ok:false,reason:'Database preflight/migration stopped; no credentials printed',code:typeof error?.code==='string'?error.code:'validation-failed',validation:/^[a-z][a-z-]+$/.test(error?.message??'')?error.message:undefined}));process.exitCode=1;}finally{if(pool)await pool.end();}
