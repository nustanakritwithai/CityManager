[CmdletBinding()]
param([ValidateSet('Plan','Apply')][string]$Mode='Plan')
$ErrorActionPreference='Stop'
$root='C:\Users\Administrator\Documents\Codex\2026-10-26\task-8\market-server-release-6269011'
$node='C:\Program Files\nodejs\node.exe'
$bundle=$PSScriptRoot
$manifest=Get-Content -LiteralPath (Join-Path $bundle 'bundle-manifest.json') -Raw|ConvertFrom-Json
$roster=@('README.md','Repair-CitySaveSchema.ps1','migration.sql','schema-repair.mjs')|Sort-Object
if($manifest.version -ne 1 -or (($manifest.files.PSObject.Properties.Name|Sort-Object)-join ',') -ne ($roster-join ',')){throw 'Unexpected repair bundle roster.'}
foreach($p in $manifest.files.PSObject.Properties){if($p.Value -notmatch '^[a-f0-9]{64}$' -or (Get-FileHash -LiteralPath (Join-Path $bundle $p.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $p.Value){throw 'Repair bundle hash mismatch.'}}
if(-not (Test-Path -LiteralPath $node -PathType Leaf) -or -not (Test-Path -LiteralPath (Join-Path $root 'src\db.js') -PathType Leaf)){throw 'Verified Node/runtime path missing.'}
function RunRepair([string]$Action){
 $previous=$ErrorActionPreference
 try{$ErrorActionPreference='Continue';$output=@(& $node (Join-Path $bundle 'schema-repair.mjs') $Action $root $bundle $manifest.files.'migration.sql' 2>&1);$exit=$LASTEXITCODE}finally{$ErrorActionPreference=$previous}
 $safe=$null;try{$safe=($output -join "`n")|ConvertFrom-Json}catch{}
 if($exit -ne 0){$code=if($safe.code -match '^[A-Za-z0-9-]+$'){$safe.code}else{'unknown'};$validation=if($safe.validation -match '^[a-z-]+$'){$safe.validation}else{'unavailable'};throw ('Schema repair stopped: '+$code+' / '+$validation+'. No source/restart/data deletion performed; committed additive tables are retained.')}
 if(-not $safe.ok -or $safe.targetSchema -ne 'citymanager_public_test'){throw 'Unexpected schema repair result.'}
 return $safe
}
$plan=RunRepair 'plan'
$plan|ConvertTo-Json -Compress
if($Mode -eq 'Apply'){
 # Apply repeats all target/owner/schema checks under the transaction lock.
 $result=RunRepair 'apply'
 $result|ConvertTo-Json -Compress
 Write-Output 'CITY_SAVE_RUNTIME_SCHEMA_READY: retry Play/Continue in the existing browser. No API restart needed.'
}else{Write-Output 'READONLY_PLAN_OK: no database or runtime changes.'}
