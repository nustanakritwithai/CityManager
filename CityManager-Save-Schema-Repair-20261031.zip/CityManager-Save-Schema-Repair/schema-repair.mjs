/** User-run only. Reads existing DB config locally, never prints credentials or SQL data. */
import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';
const [mode,rootArg,bundleArg,expectedMigrationHash]=process.argv.slice(2);let pool;
const TARGET_SCHEMA='citymanager_public_test';
const PINNED_MIGRATION='c17c6c780df6204b7ad50baa3f28b9340dc188645fcf242977fadae245721af3';
const digest=s=>createHash('sha256').update(s).digest('hex');
const tables=['city_server_snapshots','city_server_requests','city_server_archives','city_server_archive_sources','city_server_installation'];
async function fingerprint(c){
 const columns=(await c.query(`SELECT table_name,column_name,data_type,is_nullable,column_default FROM information_schema.columns WHERE table_schema='citymanager_public_test' AND table_name=ANY($1::text[]) ORDER BY table_name,ordinal_position`,[tables])).rows;
 const constraints=(await c.query(`SELECT rel.relname AS table_name,con.conname,pg_get_constraintdef(con.oid) AS definition FROM pg_constraint con JOIN pg_class rel ON rel.oid=con.conrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE ns.nspname='citymanager_public_test' AND rel.relname=ANY($1::text[]) ORDER BY rel.relname,con.conname`,[tables])).rows;
 const indexes=(await c.query(`SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='citymanager_public_test' AND tablename=ANY($1::text[]) ORDER BY tablename,indexname`,[tables])).rows;
 const triggers=(await c.query(`SELECT rel.relname AS table_name,pg_get_triggerdef(t.oid) AS definition FROM pg_trigger t JOIN pg_class rel ON rel.oid=t.tgrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE NOT t.tgisinternal AND ns.nspname='citymanager_public_test' AND rel.relname=ANY($1::text[]) ORDER BY rel.relname,t.tgname`,[tables])).rows;
 const functions=(await c.query(`SELECT pg_get_functiondef(p.oid) AS definition FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='citymanager_public_test' AND p.proname='city_server_immutable' ORDER BY p.oid`)).rows;
 return digest(JSON.stringify({columns,constraints,indexes,triggers,functions}));
}
try{
 if(!['plan','apply'].includes(mode)||!rootArg||!bundleArg||!/^[a-f0-9]{64}$/.test(expectedMigrationHash??''))throw Error('invalid-mode');
 if(expectedMigrationHash!==PINNED_MIGRATION)throw Error('unexpected-migration-version');
 if(process.env.DATABASE_SCHEMA&&process.env.DATABASE_SCHEMA!==TARGET_SCHEMA)throw Error('conflicting-schema-environment');
 process.env.DATABASE_SCHEMA=TARGET_SCHEMA;
 if(!process.env.DATABASE_URL){const raw=fs.readFileSync('C:\\ProgramData\\CityManagerMarket\\DATABASE_URL','utf8').trim();if(!raw||raw.includes('\n')||raw.includes('\r'))throw Error('database-config-format');process.env.DATABASE_URL=raw;}
 const u=new URL(process.env.DATABASE_URL);if(!['postgres:','postgresql:'].includes(u.protocol)||!['127.0.0.1','localhost'].includes(u.hostname)||u.port!=='55432'||u.pathname!=='/cm_market_sandbox')throw Error('unexpected-database-target');
 const root=path.resolve(rootArg),bundle=path.resolve(bundleArg),module=await import(pathToFileURL(path.join(root,'src/db.js')).href);pool=module.pool;if(!pool||typeof module.tx!=='function')throw Error('existing-db-contract-missing');
  const expectedModules={'service.mjs':'bdb7e9abcf0827d17c8fc955ab4fdfa5bf3a8f4b46d93cca02bc4a36dca699da','pg-store.mjs':'e43ded0d7fca50524c57a804e451eed26f45fe314fc5f78c4d55714331855f30'};
  for(const [name,expected] of Object.entries(expectedModules)){if(digest(fs.readFileSync(path.join(root,'src/city-saves',name)))!==expected)throw Error('installed-module-hash-mismatch');}

 const migration=fs.readFileSync(path.join(bundle,'migration.sql'),'utf8'),migrationHash=digest(migration);if(migrationHash!==expectedMigrationHash)throw Error('migration-payload-hash-mismatch');
 const inspect=async c=>{
  const identity=(await c.query('SELECT current_database() AS database,current_schema() AS schema,host(inet_server_addr()) AS address,inet_server_port() AS port')).rows[0];if(identity.database!=='cm_market_sandbox'||identity.schema!=='citymanager_public_test'||!['127.0.0.1','::1'].includes(identity.address)||identity.port!==55432)throw Error('unexpected-db-schema');
  const owners=(await c.query("SELECT to_regclass('accounts')::oid AS actual_accounts,to_regclass('citymanager_public_test.accounts')::oid AS expected_accounts,to_regclass('sessions')::oid AS actual_sessions,to_regclass('citymanager_public_test.sessions')::oid AS expected_sessions")).rows[0];
  if(!owners.actual_accounts||owners.actual_accounts!==owners.expected_accounts||!owners.actual_sessions||owners.actual_sessions!==owners.expected_sessions)throw Error('runtime-owner-table-mismatch');
  const present=(await c.query(`SELECT relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='citymanager_public_test' AND c.relname=ANY($1::text[])`,[tables])).rows.map(r=>r.relname);
  const functionPresent=(await c.query(`SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='citymanager_public_test' AND p.proname='city_server_immutable'`)).rowCount;
  if(!present.length&&!functionPresent)return 'absent';
  if(present.length!==tables.length||!functionPresent)throw Error('partial-or-unknown-save-schema');
  const records=(await c.query('SELECT version,migration_hash,schema_hash FROM citymanager_public_test.city_server_installation')).rows;
  const foreignKeys=(await c.query("SELECT ns.nspname AS target_schema, rel.relname AS target_table FROM pg_constraint fk JOIN pg_class src ON src.oid=fk.conrelid JOIN pg_namespace sns ON sns.oid=src.relnamespace JOIN pg_class rel ON rel.oid=fk.confrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE fk.contype='f' AND sns.nspname='citymanager_public_test' AND src.relname=ANY($1::text[])",[['city_server_snapshots','city_server_requests','city_server_archives']])).rows;
  if(foreignKeys.length!==3||foreignKeys.some(f=>f.target_schema!==TARGET_SCHEMA||f.target_table!=='accounts'))throw Error('save-owner-foreign-key-mismatch');
  if(records.length!==1||records[0].version!==1||records[0].migration_hash!==migrationHash||records[0].schema_hash!==await fingerprint(c))throw Error('save-schema-version-mismatch');return 'installed';
 };
 if(mode==='plan'){const c=await pool.connect();try{console.log(JSON.stringify({ok:true,database:'cm_market_sandbox',schema:await inspect(c),targetSchema:TARGET_SCHEMA,migrationHash,publicSaveTablesPresent:(await c.query("SELECT to_regclass('public.city_server_snapshots') IS NOT NULL AS present")).rows[0].present}));}finally{c.release();}}
 else {
  const status=await module.tx(async c=>{
   await c.query("SET LOCAL search_path = citymanager_public_test, pg_catalog");
   await c.query("SET LOCAL lock_timeout = '5s'");await c.query("SET LOCAL statement_timeout = '30s'");
   await c.query("SELECT pg_advisory_xact_lock(hashtext('CityManager-server-save-install-v1'))");const state=await inspect(c);if(state==='installed')return state;
   if((migration.match(/^BEGIN;$/gm)||[]).length!==1||(migration.match(/^COMMIT;$/gm)||[]).length!==1)throw Error('migration-wrapper-invalid');
   await c.query(migration.replace(/^BEGIN;$/m,'').replace(/^COMMIT;$/m,''));
   await c.query('CREATE TABLE citymanager_public_test.city_server_installation(version integer PRIMARY KEY,migration_hash text NOT NULL,schema_hash text NOT NULL,applied_at timestamptz NOT NULL DEFAULT now())');
   await c.query('INSERT INTO citymanager_public_test.city_server_installation(version,migration_hash,schema_hash) VALUES(1,$1,$2)',[migrationHash,await fingerprint(c)]);if(await inspect(c)!=='installed')throw Error('installed-schema-verification-failed');return 'installed';
  });
  const {randomUUID}=await import('node:crypto');
  const {createServerCityService}=await import(pathToFileURL(path.join(root,'src/city-saves/service.mjs')).href);
  const {createServerCityPgStore}=await import(pathToFileURL(path.join(root,'src/city-saves/pg-store.mjs')).href);
  const owner=randomUUID();if((await pool.query('SELECT 1 FROM citymanager_public_test.accounts WHERE id=$1',[owner])).rowCount)throw Error('synthetic-owner-collision');
  const service=createServerCityService(createServerCityPgStore({pool,tx:module.tx}));
  if(await service.read(owner)!==null||(await service.listArchives(owner)).length!==0)throw Error('empty-owner-readback-failed');
  console.log(JSON.stringify({ok:true,schema:status,targetSchema:TARGET_SCHEMA,migrationHash,readback:'nonexistent-owner-null-empty',playerDataWritten:false,publicSchemaChanged:false,restartRequired:false}));
 }
}catch(error){console.error(JSON.stringify({ok:false,reason:'Database preflight/migration stopped; no credentials printed',code:typeof error?.code==='string'?error.code:'validation-failed',validation:/^[a-z][a-z-]+$/.test(error?.message??'')?error.message:undefined}));process.exitCode=1;}finally{if(pool)await pool.end();}
