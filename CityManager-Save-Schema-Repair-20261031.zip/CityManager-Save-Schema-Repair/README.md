# CityManager runtime save-schema repair

The verified API startup uses DATABASE_SCHEMA=citymanager_public_test. The earlier installer created separate city-save tables in public instead. This package repairs only the missing city-save objects in the already-existing runtime schema; it does not change runtime environment, authentication, accounts, source files, startup integrity checks, Caddy or any public-schema data. No restart is required.

Verify the ZIP hash supplied separately and extract into a fresh folder. In existing Windows PowerShell:

```powershell
& '.\CityManager-Save-Schema-Repair\Repair-CitySaveSchema.ps1' -Mode Apply
```

Apply first runs a read-only plan and then repeats all database/namespace/owner checks inside the transaction. Use -Mode Plan alone for diagnostics. Exact target: loopback PostgreSQL port55432, database cm_market_sandbox, schema citymanager_public_test. Existing runtime db.js pool/transaction and installed service/store modules are used, with hashes checked. Unknown/partial schema or wrong owner foreign keys stop without migration.

The unchanged reviewed migration creates the four save tables, immutable archive trigger/function and installation marker atomically. Foreign keys must reference accounts in citymanager_public_test, not public. Public save tables and all original browser saves remain untouched. A random UUID is verified absent from runtime accounts, then service GET/list calls must return null/empty; no player save/account is written by this test.

Transaction failure rolls back newly created objects. Once COMMIT succeeds, additive objects are retained even if the readback later fails; there is no DROP, data deletion or destructive rollback. Retry is idempotent only for an exact matching installed schema fingerprint. Credentials are read locally by the helper and never printed or included here.

After CITY_SAVE_RUNTIME_SCHEMA_READY, retry Play/Continue in the existing game browser/account. Real existing-account migration/save/reload is still the final acceptance test. Node syntax and five focused mock tests were run in cloud; Windows PowerShell and real PostgreSQL execution of this repair remain user-run checks, not claimed completed.
