const decode=row=>{if(!row)return null;const revision=Number(row.revision);if(!Number.isSafeInteger(revision)||revision<1)throw Error('invalid-stored-revision');if(row.deleted)return {owner:row.account_id,cityId:row.city_id,revision,deleted:true,archiveHash:row.archive_hash};if(typeof row.raw!=='string')throw Error('active-head-snapshot-missing');return {owner:row.account_id,cityId:row.city_id,revision,raw:row.raw,rawHash:row.raw_hash,metadata:row.metadata};};
const currentSQL=`SELECT h.account_id,h.city_id,h.revision,h.deleted,h.archive_hash,s.raw,s.raw_hash,s.metadata FROM city_server_heads h LEFT JOIN city_server_snapshots s ON s.account_id=h.account_id AND s.revision=h.revision WHERE h.account_id=$1
 UNION ALL SELECT s.account_id,s.city_id,s.revision,false AS deleted,NULL AS archive_hash,s.raw,s.raw_hash,s.metadata FROM city_server_snapshots s WHERE s.account_id=$1 AND NOT EXISTS(SELECT 1 FROM city_server_heads h WHERE h.account_id=$1) ORDER BY revision DESC LIMIT 1`;
export function createServerCityPgStore({pool,tx}){return {
 read:async owner=>decode((await pool.query(currentSQL,[owner])).rows[0]),
 transaction(owner,work){return tx(async client=>{
  const lock=await client.query('SELECT id FROM accounts WHERE id=$1 FOR UPDATE',[owner]);if(!lock.rowCount)throw Object.assign(Error('guest-required'),{status:401});
  return work({
   bytes:async()=>Number((await client.query('SELECT COALESCE((SELECT sum(octet_length(raw)) FROM city_server_snapshots WHERE account_id=$1),0)+COALESCE((SELECT sum(octet_length(raw)) FROM city_server_archives WHERE account_id=$1),0) AS bytes',[owner])).rows[0].bytes),
   hasArchive:async h=>(await client.query('SELECT 1 FROM city_server_archives WHERE account_id=$1 AND raw_hash=$2',[owner,h])).rowCount>0,
   deletionFence:async()=>Number((await client.query('SELECT last_deleted_revision FROM city_server_heads WHERE account_id=$1',[owner])).rows[0]?.last_deleted_revision??0),
   wasRetired:async cityId=>(await client.query("SELECT 1 FROM city_server_requests WHERE account_id=$1 AND response->>'cityId'=$2 AND response->>'deleted'='true' LIMIT 1",[owner,cityId])).rowCount>0,
   resetAllowed:async()=>{try{
    const listing=await client.query("SELECT EXISTS(SELECT 1 FROM listings WHERE seller_id=$1 AND status='open') AS blocked",[owner]);if(listing.rows[0].blocked!==false)return false;
    // Account inbox rows are retained, not ACKed/transferred. Lock against concurrent claim/ACK.
    const pending=await client.query('SELECT operation_id,claim_id,claimed_at,claim_expires_at FROM delivery_receipts WHERE buyer_id=$1 AND acknowledged_at IS NULL ORDER BY operation_id FOR UPDATE',[owner]);
    if(pending.rows.some(r=>r.claim_id!==null||r.claimed_at!==null||r.claim_expires_at!==null))return false;
    if(!pending.rows.length)return true;
    const history=await client.query('SELECT 1 FROM receipt_claim_history WHERE receipt_id=ANY($1::uuid[]) LIMIT 1',[pending.rows.map(r=>r.operation_id)]);
    return history.rowCount===0;
   }catch(e){if(['42P01','42703'].includes(e.code))throw Object.assign(Error('market-contract-unverified'),{status:409});throw e;}},
   current:async()=>decode((await client.query(currentSQL,[owner])).rows[0]),
   requestCount:async()=>Number((await client.query('SELECT count(*) AS count FROM city_server_requests WHERE account_id=$1',[owner])).rows[0].count),
   request:async id=>{const r=(await client.query('SELECT payload_hash,response FROM city_server_requests WHERE account_id=$1 AND request_id=$2',[owner,id])).rows[0];return r?{payloadHash:r.payload_hash,response:r.response}:null;},
   record:(id,h,response)=>{const {raw,...receipt}=response;return client.query('INSERT INTO city_server_requests(account_id,request_id,payload_hash,response) VALUES($1,$2,$3,$4)',[owner,id,h,JSON.stringify(receipt)]);},
   publish:async v=>{await client.query('INSERT INTO city_server_snapshots(account_id,revision,city_id,raw,raw_hash,metadata) VALUES($1,$2,$3,$4,$5,$6)',[owner,v.revision,v.cityId,v.raw,v.rawHash,JSON.stringify(v.metadata)]);await client.query('DELETE FROM city_server_snapshots WHERE account_id=$1 AND revision<$2',[owner,v.revision-1]);await client.query('INSERT INTO city_server_heads(account_id,city_id,revision,deleted,last_deleted_revision) VALUES($1,$2,$3,false,0) ON CONFLICT(account_id) DO UPDATE SET city_id=EXCLUDED.city_id,revision=EXCLUDED.revision,deleted=false,archive_hash=NULL',[owner,v.cityId,v.revision]);},
   retire:async v=>{
    const copies=(await client.query('SELECT revision,city_id,raw,raw_hash FROM city_server_snapshots WHERE account_id=$1 ORDER BY revision',[owner])).rows;
    if(!copies.length)throw Error('delete-snapshot-missing');
    for(const copy of copies){
     await client.query('INSERT INTO city_server_archives(account_id,raw_hash,raw) VALUES($1,$2,$3) ON CONFLICT DO NOTHING',[owner,copy.raw_hash,copy.raw]);
     const archived=(await client.query('SELECT raw FROM city_server_archives WHERE account_id=$1 AND raw_hash=$2',[owner,copy.raw_hash])).rows[0];if(archived?.raw!==copy.raw)throw Error('archive-hash-collision');
     await client.query('INSERT INTO city_server_archive_sources(account_id,raw_hash,source) VALUES($1,$2,$3) ON CONFLICT DO NOTHING',[owner,copy.raw_hash,`deleted:${copy.city_id}:${v.revision}:snapshot:${copy.revision}`]);
    }
    await client.query('INSERT INTO city_server_heads(account_id,city_id,revision,deleted,last_deleted_revision,archive_hash) VALUES($1,$2,$3,true,$3,$4) ON CONFLICT(account_id) DO UPDATE SET city_id=EXCLUDED.city_id,revision=EXCLUDED.revision,deleted=true,last_deleted_revision=EXCLUDED.revision,archive_hash=EXCLUDED.archive_hash',[owner,v.cityId,v.revision,v.archiveHash]);
    await client.query('DELETE FROM city_server_snapshots WHERE account_id=$1',[owner]);
   },
   archive:async(h,raw,source)=>{await client.query('INSERT INTO city_server_archives(account_id,raw_hash,raw) VALUES($1,$2,$3) ON CONFLICT DO NOTHING',[owner,h,raw]);const stored=(await client.query('SELECT raw FROM city_server_archives WHERE account_id=$1 AND raw_hash=$2',[owner,h])).rows[0];if(stored?.raw!==raw)throw Error('archive-hash-collision');await client.query('INSERT INTO city_server_archive_sources(account_id,raw_hash,source) VALUES($1,$2,$3) ON CONFLICT DO NOTHING',[owner,h,source]);}
  });
 });},
 async listArchives(owner){const r=await pool.query('SELECT a.raw_hash AS hash,a.created_at AS "createdAt",array_agg(s.source ORDER BY s.source) AS sources FROM city_server_archives a JOIN city_server_archive_sources s USING(account_id,raw_hash) WHERE a.account_id=$1 GROUP BY a.raw_hash,a.created_at ORDER BY a.created_at,a.raw_hash',[owner]);return r.rows;},
 async readArchive(owner,h){const r=await pool.query('SELECT a.raw_hash AS hash,a.raw,array_agg(s.source ORDER BY s.source) AS sources FROM city_server_archives a JOIN city_server_archive_sources s USING(account_id,raw_hash) WHERE a.account_id=$1 AND a.raw_hash=$2 GROUP BY a.raw_hash,a.raw',[owner,h]);return r.rows[0]??null;}
};}
