# CityManager — preserve untouched account inbox when deleting a city

This narrowly changes only the deployed pg-store.mjs and its one existing startup integrity hash. No SQL migration, frontend, Caddy, account credentials, wallet, ledger, receipt ACK/cancel, inventory transfer or other source changes. service.mjs in this package is an unchanged validation dependency and is NOT copied to the server.

A city may be deleted only when its existing local financial guards and open-listing guard pass. Pending account receipts no longer block merely for existing: every pending receipt must have NULL claim_id, claimed_at and claim_expires_at and NO claim history. Deterministically ordered FOR UPDATE locks protect the decision. Claimed, expired, contradictory timestamp or previously handled receipts still block. Pending receipts remain byte-for-byte in the same account inbox; they are neither applied nor copied to the new city.

Preflight verifies the exact existing schema and validated, nondeferrable foreign keys from claim history to the exact receipt key and from receipts to accounts. Unknown contracts stop. A bounded TEMP-only transaction checks pristine receipts, blocked claim/history cases and byte-equivalent inbox preservation through simulated delete/new-city; it always rolls back and never writes real accounts or receipts.

After verifying the separately supplied ZIP SHA256, extract fresh and run in existing Windows PowerShell:

```powershell
& '.\CityManager-Inbox-Preservation\Update-InboxPreservation.ps1' -Mode Apply
```

-Mode Plan performs read-only database/runtime checks and local staging only. Apply verifies all seven existing guard entries and file hashes, snapshots/rechecks the sole loopback API process and unchanged startup task, tests atomic replacement on both volumes, saves verified backups, runs the TEMP rollback fixture, changes only the adapter/hash, and restarts only that task. No player city is deleted by the installer. Real deletion still requires the user's in-game confirmation.

Rollback restores the pinned PREVIOUS HEAD-AWARE adapter and guard, retaining all heads, tombstones, archives, receipts and account data. It never reinstalls the retired legacy snapshot-only backend. If rollback cannot be safely verified, the API may remain stopped and backups are retained for recovery.

Cloud evidence: eight focused inbox/adapter/guard tests and Node syntax checks pass. Real Windows/PostgreSQL execution remains user-run evidence; no claim of production update is made by this file. No credentials or player payloads are included in the package.
