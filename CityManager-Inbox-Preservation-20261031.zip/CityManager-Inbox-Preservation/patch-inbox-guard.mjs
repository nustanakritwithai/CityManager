import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import {fileURLToPath} from 'node:url';
const hash=b=>createHash('sha256').update(b).digest('hex');
const known={'src\\startup-guard.js':'dec068bc47b2ce02162eb39a1f3948c82f2fd143ba4e02ab0e1e9ffea26d5b90','src\\owner-pin-auth.js':'e32ee986286fe6684f8e07a05fa0efc1c3b520ae9dabb02a75e03e2911bb6078','src\\city-saves\\service.mjs':'103a44ee505bc938f5a69994baaab5f2cd4372b7cf567b5bdc31163fd2f217d1','src\\city-saves\\pg-store.mjs':'dddef50be2cba64397c67917528ce337e5f3e44c09d9f9956e121f71228e7531','src\\city-saves\\router.mjs':'2a54010ec3a984c61d9005d19a3830c44abf2e901fcf4dfca385a88d177f90e6'};
export function patchGuard(bytes,expected,replacements){
 const text=bytes.toString('utf8');if(!Buffer.from(text).equals(bytes))throw Error('startup-encoding');
 const found=[...text.matchAll(/\$guard\s*=\s*@\{([^}]*?)\}/g)];if(found.length!==1)throw Error('guard-assignment-count');const m=found[0];
 const entry=/(['"])(src\\[^'"\r\n]+)\1\s*=\s*(['"])([a-fA-F0-9]{64})\3/g,entries=[...m[1].matchAll(entry)];
 if(entries.length!==7||m[1].replace(entry,'').replace(/[;\s]/g,'')!=='')throw Error('guard-shape');const seen=new Set();
 for(const e of entries){if(seen.has(e[2])||expected[e[2]]!==e[4].toLowerCase())throw Error('guard-entry-drift');seen.add(e[2]);}
 if(Object.keys(expected).length!==7||Object.keys(replacements).sort().join('|')!=='src\\city-saves\\pg-store.mjs'||Object.values(replacements).some(h=>!/^[a-f0-9]{64}$/.test(h)))throw Error('guard-replacement-roster');
 const body=m[1].replace(entry,(whole,q,key,q2,value)=>replacements[key]?whole.replace(value,replacements[key].toUpperCase()):whole);
 const start=m.index+m[0].indexOf('{')+1;return Buffer.from(text.slice(0,start)+body+text.slice(start+m[1].length));
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const [root,startup,bundle,out]=process.argv.slice(2),manifest=JSON.parse(fs.readFileSync(path.join(root,'src/city-saves/install-manifest.json'),'utf8').replace(/^\uFEFF/,''));
  const management=JSON.parse(fs.readFileSync(path.join(root,'src/city-saves/management-install-manifest.json'),'utf8').replace(/^\uFEFF/,''));
  const bytes=fs.readFileSync(startup);if(management.version!==1||management.bundleHash!=='669cdd883b24c64b73b69c5ae3a4f77420d642eb05ca1d770587d66664862d57'||manifest.version!==1||manifest.startupOriginalHash!=='c7139d654e3ed106680fe2db1b8701f3a2cfd08ca906e541d7a16c6fce176ee3'||hash(bytes)!==management.startupHash)throw Error('installed-startup-drift');
  const expected={...known};for(const n of ['server.js','pages-auth.js']){const k='src/'+n,h=manifest.installed[k];if(!/^[a-f0-9]{64}$/.test(h))throw Error('installed-source-hash');expected['src\\'+n]=h;}
  for(const [n,h]of Object.entries(expected))if(hash(fs.readFileSync(path.join(root,...n.split('\\'))))!==h)throw Error('guarded-source-drift');
  const replacements=Object.fromEntries(['pg-store.mjs'].map(n=>['src\\city-saves\\'+n,hash(fs.readFileSync(path.join(bundle,n)))]));const next=patchGuard(bytes,expected,replacements);fs.writeFileSync(out,next,{flag:'wx'});
  console.log(JSON.stringify({originalHash:hash(bytes),candidateHash:hash(next),originalModules:{'service.mjs':known['src\\city-saves\\service.mjs'],'pg-store.mjs':known['src\\city-saves\\pg-store.mjs']},candidateModules:Object.fromEntries(Object.entries(replacements).map(([k,h])=>[k.split('\\').at(-1),h]))}));
 }catch(e){console.error(JSON.stringify({ok:false,validation:e.message}));process.exitCode=1;}
}
