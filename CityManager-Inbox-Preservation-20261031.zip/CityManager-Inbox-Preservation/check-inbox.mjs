import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';import {randomUUID} from 'node:crypto';
const [mode,root,bundle]=process.argv.slice(2);let pool,c;
try{
 if(!['plan','validate'].includes(mode))throw Error('invalid-mode');
 if(process.env.DATABASE_SCHEMA&&process.env.DATABASE_SCHEMA!=='citymanager_public_test')throw Error('schema-environment-mismatch');process.env.DATABASE_SCHEMA='citymanager_public_test';
 if(!process.env.DATABASE_URL)process.env.DATABASE_URL=fs.readFileSync('C:\\ProgramData\\CityManagerMarket\\DATABASE_URL','utf8').trim();
 const u=new URL(process.env.DATABASE_URL);if(!['postgres:','postgresql:'].includes(u.protocol)||!['127.0.0.1','localhost'].includes(u.hostname)||u.port!=='55432'||u.pathname!=='/cm_market_sandbox')throw Error('database-target-mismatch');
 const module=await import(pathToFileURL(path.join(root,'src/db.js')).href);pool=module.pool;c=await pool.connect();
 await c.query('BEGIN READ ONLY');await c.query("SET LOCAL statement_timeout='10s'");
 const id=(await c.query('SELECT current_database() db,current_schema() s,host(inet_server_addr()) h,inet_server_port() p')).rows[0];if(id.db!=='cm_market_sandbox'||id.s!=='citymanager_public_test'||!['127.0.0.1','::1'].includes(id.h)||id.p!==55432)throw Error('runtime-target-mismatch');
 const columns=(await c.query("SELECT table_name,column_name,data_type FROM information_schema.columns WHERE table_schema='citymanager_public_test' AND table_name IN ('delivery_receipts','receipt_claim_history','listings')")).rows;
 const names=columns.filter(x=>x.table_name==='delivery_receipts').map(x=>x.column_name).sort();if(names.join(',')!=='acknowledged_at,buyer_id,claim_expires_at,claim_id,claimed_at,delivered_at,item_code,operation_id,quantity')throw Error('receipt-column-contract-changed');
 const required={'delivery_receipts.operation_id':'uuid','delivery_receipts.buyer_id':'uuid','delivery_receipts.claim_id':'uuid','delivery_receipts.claimed_at':'timestamp with time zone','delivery_receipts.claim_expires_at':'timestamp with time zone','delivery_receipts.acknowledged_at':'timestamp with time zone','receipt_claim_history.receipt_id':'uuid','listings.seller_id':'uuid','listings.status':'text'};
 for(const [key,type]of Object.entries(required))if(!columns.some(x=>x.table_name+'.'+x.column_name===key&&x.data_type===type))throw Error('receipt-type-contract-changed');
 const historyFk=(await c.query("SELECT EXISTS(SELECT 1 FROM pg_constraint k JOIN pg_attribute a ON a.attrelid=k.conrelid AND a.attname='receipt_id' JOIN pg_attribute b ON b.attrelid=k.confrelid AND b.attname='operation_id' WHERE k.contype='f' AND k.conrelid='citymanager_public_test.receipt_claim_history'::regclass AND k.confrelid='citymanager_public_test.delivery_receipts'::regclass AND k.conkey=ARRAY[a.attnum] AND k.confkey=ARRAY[b.attnum] AND k.convalidated AND NOT k.condeferrable) AS valid")).rows[0];
 const ownerFk=(await c.query("SELECT EXISTS(SELECT 1 FROM pg_constraint k JOIN pg_attribute a ON a.attrelid=k.conrelid AND a.attname='buyer_id' JOIN pg_attribute b ON b.attrelid=k.confrelid AND b.attname='id' WHERE k.contype='f' AND k.conrelid='citymanager_public_test.delivery_receipts'::regclass AND k.confrelid='citymanager_public_test.accounts'::regclass AND k.conkey=ARRAY[a.attnum] AND k.confkey=ARRAY[b.attnum] AND k.convalidated AND NOT k.condeferrable) AS valid")).rows[0];
 if(!historyFk.valid||!ownerFk.valid)throw Error('receipt-locking-foreign-key-contract-unverified');
 const tables=(await c.query("SELECT count(*)::int n FROM information_schema.tables WHERE table_schema='citymanager_public_test' AND table_name IN ('city_server_snapshots','city_server_requests','city_server_archives','city_server_archive_sources','city_server_heads','city_server_management_installation')")).rows[0];if(tables.n!==6)throw Error('head-aware-schema-required');
 await c.query('ROLLBACK');c.release();c=null;
 if(mode==='validate'){
  const {createServerCityService}=await import(pathToFileURL(path.join(bundle,'service.mjs')).href),{createServerCityPgStore}=await import(pathToFileURL(path.join(bundle,'pg-store.mjs')).href);
  const sentinel=Error('inbox-fixture-rollback');let finished=false;
  try{await module.tx(async t=>{
   await t.query("SET LOCAL lock_timeout='5s'");await t.query("SET LOCAL statement_timeout='30s'");await t.query('CREATE TEMP TABLE accounts(id uuid PRIMARY KEY) ON COMMIT DROP');await t.query('SET LOCAL search_path=pg_temp,pg_catalog');
   for(const name of ['city_server_snapshots','city_server_requests','city_server_archives','city_server_archive_sources','city_server_heads'])await t.query(`CREATE TEMP TABLE ${name} (LIKE citymanager_public_test.${name} INCLUDING ALL) ON COMMIT DROP`);
   await t.query('CREATE TEMP TABLE listings(seller_id uuid,status text) ON COMMIT DROP');
   await t.query('CREATE TEMP TABLE delivery_receipts(operation_id uuid PRIMARY KEY,buyer_id uuid REFERENCES accounts(id),item_code text,quantity bigint,delivered_at timestamptz,acknowledged_at timestamptz,claim_id uuid,claimed_at timestamptz,claim_expires_at timestamptz) ON COMMIT DROP');
   await t.query('CREATE TEMP TABLE receipt_claim_history(receipt_id uuid REFERENCES delivery_receipts(operation_id)) ON COMMIT DROP');
   const owner=randomUUID(),oldCity=randomUUID(),newCity=randomUUID(),receipt=randomUUID();await t.query('INSERT INTO pg_temp.accounts(id) VALUES($1)',[owner]);
   for(const op of [receipt,randomUUID(),randomUUID()])await t.query("INSERT INTO pg_temp.delivery_receipts(operation_id,buyer_id,item_code,quantity,delivered_at) VALUES($1,$2,'fixture',7,now())",[op,owner]);
   const store=createServerCityPgStore({pool:{query:(...a)=>t.query(...a)},tx:fn=>fn(t)}),service=createServerCityService(store);
   if(!await store.transaction(owner,db=>db.resetAllowed()))throw Error('pristine-inbox-rejected');
   for(const field of ['claim_id','claimed_at','claim_expires_at']){
    await t.query(`UPDATE pg_temp.delivery_receipts SET ${field}=$1 WHERE operation_id=$2`,[field==='claim_id'?randomUUID():new Date(0),receipt]);
    if(await store.transaction(owner,db=>db.resetAllowed()))throw Error('claimed-or-expired-receipt-accepted');
    await t.query(`UPDATE pg_temp.delivery_receipts SET ${field}=NULL WHERE operation_id=$1`,[receipt]);
   }
   await t.query('INSERT INTO pg_temp.receipt_claim_history(receipt_id) VALUES($1)',[receipt]);if(await store.transaction(owner,db=>db.resetAllowed()))throw Error('historical-claim-accepted');await t.query('DELETE FROM pg_temp.receipt_claim_history');
   const before=JSON.stringify((await t.query('SELECT * FROM pg_temp.delivery_receipts ORDER BY operation_id')).rows),metadata={name:'Temporary inbox fixture',population:0,tick:0},raw='{"version":23,"tick":0}';
   await service.mutate(owner,randomUUID(),{action:'create',cityId:oldCity,raw,metadata});await service.mutate(owner,randomUUID(),{action:'delete',cityId:oldCity,expectedRevision:1});
   const fresh=JSON.stringify({version:23,tick:0,market:{version:10,rulesVersion:'chain-5',guestId:owner,cityId:newCity,operations:[],escrow:[],receipts:{},seq:'0'}});
   const made=await service.mutate(owner,randomUUID(),{action:'create',cityId:newCity,expectedRevision:2,raw:fresh,metadata});
   if(made.revision!==3||JSON.stringify((await t.query('SELECT * FROM pg_temp.delivery_receipts ORDER BY operation_id')).rows)!==before)throw Error('account-inbox-changed');
   finished=true;throw sentinel;
  });}catch(e){if(e!==sentinel)throw e;}
  if(!finished)throw Error('fixture-not-completed');
 }
 console.log(JSON.stringify({ok:true,schema:'citymanager_public_test',receiptContractVerified:true,immediateValidatedForeignKeys:true,temporaryFixtureRolledBack:mode==='validate',playerDataWritten:false}));
}catch(e){if(c)try{await c.query('ROLLBACK');}catch{}console.error(JSON.stringify({ok:false,validation:/^[a-z-]+$/.test(e.message??'')?e.message:'validation-failed',code:typeof e.code==='string'&&/^[A-Z0-9]{5}$/.test(e.code)?e.code:undefined}));process.exitCode=1;}finally{c?.release();if(pool)await pool.end();}
