CityManager existing-login city-save: PLAN ONLY

Run Plan-CitySave.ps1 from an elevated Windows PowerShell on the existing VPS.
The script validates the exact source hashes already backed up by the user,
checks the current Node process/startup task, health and Pages CORS headers,
stages proposed source copies into a new TEMP report folder, and runs read-only
schema checks through the existing db.js pool. It does not alter live source,
create tables/accounts, restart/stop processes, change access policies or write
player saves. There is no Apply switch, migration SQL or restart implementation
in this package.

The database helper may read the existing protected DATABASE_URL file LOCALLY
only if the existing process environment lacks that setting. It never prints
its value. It validates the loopback database target and does not persist the
setting. Do not upload configuration, tokens, cookies or source files from the
report folder. Return only PLAN_OK JSON (preflight-report.json) or the error.

This package passed Node syntax/mock-patch tests. Windows PowerShell and actual
PostgreSQL execution have not yet been tested; this Plan supplies that evidence
without applying the proposed change. Stop if any check fails; don't bypass it.
