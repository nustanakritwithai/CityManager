import fs from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const hash=b=>createHash('sha256').update(b).digest('hex');
export const ORIGINAL_STARTUP='c7139d654e3ed106680fe2db1b8701f3a2cfd08ca906e541d7a16c6fce176ee3';
const guards={
 'src\\server.js':'8affc2803830b8333caa4595dbf0a80fd8a4609e07c40e16ce1567ac4fdc4bb3',
 'src\\startup-guard.js':'dec068bc47b2ce02162eb39a1f3948c82f2fd143ba4e02ab0e1e9ffea26d5b90',
 'src\\pages-auth.js':'66c98ff9fcc434038982a062178532921825274f7097df65bfeca262ae14662f',
 'src\\owner-pin-auth.js':'e32ee986286fe6684f8e07a05fa0efc1c3b520ae9dabb02a75e03e2911bb6078'
};
export function patchStartup(bytes,replacements){
 const text=bytes.toString('utf8');if(!Buffer.from(text,'utf8').equals(bytes))throw Error('startup-encoding-not-utf8');
 const matches=[...text.matchAll(/\$guard\s*=\s*@\{([^}]*?)\}/g)];if(matches.length!==1)throw Error('startup-guard-assignment-count');
 const m=matches[0],body=m[1];const entry=/(['"])(src\\[^'"\r\n]+)\1\s*=\s*(['"])([a-fA-F0-9]{64})\3/g;
 const found=[...body.matchAll(entry)];if(found.length!==4||body.replace(entry,'').replace(/[;\s]/g,'')!=='')throw Error('startup-guard-shape');
 const seen=new Set();for(const e of found){if(seen.has(e[2])||guards[e[2]]!==e[4].toLowerCase())throw Error('startup-guard-unexpected-entry');seen.add(e[2]);}
 const expected=['src\\server.js','src\\pages-auth.js','src\\city-saves\\service.mjs','src\\city-saves\\pg-store.mjs','src\\city-saves\\router.mjs'];
 if(Object.keys(replacements).sort().join('|')!==expected.sort().join('|')||Object.values(replacements).some(v=>!/^[a-f0-9]{64}$/.test(v)))throw Error('startup-replacement-roster');
 let newBody=body.replace(entry,(whole,q,key,q2,value)=>replacements[key]?whole.replace(value,replacements[key].toUpperCase()):whole);
 const newline=text.includes('\r\n')?'\r\n':'\n';
 newBody+=newline+['service.mjs','pg-store.mjs','router.mjs'].map(n=>`  'src\\city-saves\\${n}' = '${replacements['src\\city-saves\\'+n].toUpperCase()}'`).join(';'+newline)+newline;
 const start=m.index+m[0].indexOf('{')+1,end=start+body.length;
 return Buffer.from(text.slice(0,start)+newBody+text.slice(end),'utf8');
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const [startup,plan,bundle,out]=process.argv.slice(2);const original=fs.readFileSync(startup);if(hash(original)!==ORIGINAL_STARTUP)throw Error('startup-original-hash-mismatch');
 const replacements={'src\\server.js':hash(fs.readFileSync(path.join(plan,'server.js'))),'src\\pages-auth.js':hash(fs.readFileSync(path.join(plan,'pages-auth.js')))};
 for(const n of ['service.mjs','pg-store.mjs','router.mjs'])replacements['src\\city-saves\\'+n]=hash(fs.readFileSync(path.join(bundle,n)));
 const candidate=patchStartup(original,replacements);fs.writeFileSync(out,candidate,{flag:'wx'});console.log(JSON.stringify({originalHash:hash(original),candidateHash:hash(candidate),outsideGuardPreserved:true}));
 }catch(e){console.error(JSON.stringify({error:e.message}));process.exitCode=1;}
}
