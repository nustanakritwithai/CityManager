# CityManager guarded save API installation

This package supersedes the previous Apply and Resume bundles. It pins the recovered original process PID 9264, creation 2026-10-31T17:16:52.3305650+07:00, original source hashes and original startup script SHA256.

Authorized change: existing-login owner-only city save/load/archive routes and separate save tables. Existing startup integrity checking stays enabled: only the two changed source hashes are updated and three new module hashes added to its exact four-entry dictionary. The startup-guard and owner-PIN hashes, pg_hba check and all script bytes outside the dictionary are preserved. No secrets or live startup source are included in this package.

Verify the ZIP SHA256 supplied separately, extract to a fresh directory, then use existing Windows PowerShell:

```powershell
& '.\CityManager-Save-Guarded\installer\Install-CitySave.ps1' -Mode Apply -PlanDirectory 'C:\Users\ADMINI~1\AppData\Local\Temp\2\city-save-plan-20261031-165150'
```

The installer parses the generated startup script and exercises real atomic create/replace/restore on both source and startup volumes BEFORE stopping the API. It verifies backups of both source files and startup.ps1, checks the existing installed save schema fingerprint, runs an isolated TEMP transaction rollback test, rechecks process/task identity, and restarts only the existing task. Failure restores original source and startup guards; additive tables, staged modules, backups and original browser saves remain. Unknown files, hashes or process/task changes stop installation.

Successful installation requires health200 and unauthenticated save401. Existing-account browser save/load and Pages preflight still need end-to-end verification; no player city is written by this installer. Market stays disabled. Do not rerun superseded bundles.
