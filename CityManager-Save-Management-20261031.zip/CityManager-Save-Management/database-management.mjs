/** User-run only. Reads existing DB config locally, never prints credentials or SQL data. */
import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';
const [mode,rootArg,bundleArg,expectedMigrationHash]=process.argv.slice(2);let pool;
const TARGET_SCHEMA='citymanager_public_test';
const BASE_MIGRATION='c17c6c780df6204b7ad50baa3f28b9340dc188645fcf242977fadae245721af3';
const digest=s=>createHash('sha256').update(s).digest('hex');
const tables=['city_server_snapshots','city_server_requests','city_server_archives','city_server_archive_sources','city_server_installation'];
async function fingerprint(c){
 const columns=(await c.query(`SELECT table_name,column_name,data_type,is_nullable,column_default FROM information_schema.columns WHERE table_schema='citymanager_public_test' AND table_name=ANY($1::text[]) ORDER BY table_name,ordinal_position`,[tables])).rows;
 const constraints=(await c.query(`SELECT rel.relname AS table_name,con.conname,pg_get_constraintdef(con.oid) AS definition FROM pg_constraint con JOIN pg_class rel ON rel.oid=con.conrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE ns.nspname='citymanager_public_test' AND rel.relname=ANY($1::text[]) ORDER BY rel.relname,con.conname`,[tables])).rows;
 const indexes=(await c.query(`SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='citymanager_public_test' AND tablename=ANY($1::text[]) ORDER BY tablename,indexname`,[tables])).rows;
 const triggers=(await c.query(`SELECT rel.relname AS table_name,pg_get_triggerdef(t.oid) AS definition FROM pg_trigger t JOIN pg_class rel ON rel.oid=t.tgrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE NOT t.tgisinternal AND ns.nspname='citymanager_public_test' AND rel.relname=ANY($1::text[]) ORDER BY rel.relname,t.tgname`,[tables])).rows;
 const functions=(await c.query(`SELECT pg_get_functiondef(p.oid) AS definition FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='citymanager_public_test' AND p.proname='city_server_immutable' ORDER BY p.oid`)).rows;
 return digest(JSON.stringify({columns,constraints,indexes,triggers,functions}));
}
try{
 if(!['plan','apply','verify','rollback-safe'].includes(mode)||!rootArg||!bundleArg||!/^[a-f0-9]{64}$/.test(expectedMigrationHash??''))throw Error('invalid-mode');
 
 if(process.env.DATABASE_SCHEMA&&process.env.DATABASE_SCHEMA!==TARGET_SCHEMA)throw Error('conflicting-schema-environment');
 process.env.DATABASE_SCHEMA=TARGET_SCHEMA;
 if(!process.env.DATABASE_URL){const raw=fs.readFileSync('C:\\ProgramData\\CityManagerMarket\\DATABASE_URL','utf8').trim();if(!raw||raw.includes('\n')||raw.includes('\r'))throw Error('database-config-format');process.env.DATABASE_URL=raw;}
 const u=new URL(process.env.DATABASE_URL);if(!['postgres:','postgresql:'].includes(u.protocol)||!['127.0.0.1','localhost'].includes(u.hostname)||u.port!=='55432'||u.pathname!=='/cm_market_sandbox')throw Error('unexpected-database-target');
 const root=path.resolve(rootArg),bundle=path.resolve(bundleArg),module=await import(pathToFileURL(path.join(root,'src/db.js')).href);pool=module.pool;if(!pool||typeof module.tx!=='function')throw Error('existing-db-contract-missing');
 const migration=fs.readFileSync(path.join(bundle,'migration-management.sql'),'utf8'),migrationHash=digest(migration);if(migrationHash!==expectedMigrationHash)throw Error('migration-payload-hash-mismatch');
 const inspect=async c=>{
  const identity=(await c.query('SELECT current_database() AS database,current_schema() AS schema,host(inet_server_addr()) AS address,inet_server_port() AS port')).rows[0];if(identity.database!=='cm_market_sandbox'||identity.schema!=='citymanager_public_test'||!['127.0.0.1','::1'].includes(identity.address)||identity.port!==55432)throw Error('unexpected-db-schema');
  const owners=(await c.query("SELECT to_regclass('accounts')::oid AS actual_accounts,to_regclass('citymanager_public_test.accounts')::oid AS expected_accounts,to_regclass('sessions')::oid AS actual_sessions,to_regclass('citymanager_public_test.sessions')::oid AS expected_sessions")).rows[0];
  if(!owners.actual_accounts||owners.actual_accounts!==owners.expected_accounts||!owners.actual_sessions||owners.actual_sessions!==owners.expected_sessions)throw Error('runtime-owner-table-mismatch');
  const present=(await c.query(`SELECT relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='citymanager_public_test' AND c.relname=ANY($1::text[])`,[tables])).rows.map(r=>r.relname);
  const functionPresent=(await c.query(`SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='citymanager_public_test' AND p.proname='city_server_immutable'`)).rowCount;
  if(!present.length&&!functionPresent)return 'absent';
  if(present.length!==tables.length||!functionPresent)throw Error('partial-or-unknown-save-schema');
  const records=(await c.query('SELECT version,migration_hash,schema_hash FROM citymanager_public_test.city_server_installation')).rows;
  const foreignKeys=(await c.query("SELECT ns.nspname AS target_schema, rel.relname AS target_table FROM pg_constraint fk JOIN pg_class src ON src.oid=fk.conrelid JOIN pg_namespace sns ON sns.oid=src.relnamespace JOIN pg_class rel ON rel.oid=fk.confrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE fk.contype='f' AND sns.nspname='citymanager_public_test' AND src.relname=ANY($1::text[])",[['city_server_snapshots','city_server_requests','city_server_archives']])).rows;
  if(foreignKeys.length!==3||foreignKeys.some(f=>f.target_schema!==TARGET_SCHEMA||f.target_table!=='accounts'))throw Error('save-owner-foreign-key-mismatch');
  if(records.length!==1||records[0].version!==1||records[0].migration_hash!==BASE_MIGRATION||records[0].schema_hash!==await fingerprint(c))throw Error('save-schema-version-mismatch');return 'installed';
 };

 const headFingerprint=async c=>digest(JSON.stringify({
  columns:(await c.query("SELECT table_name,column_name,data_type,is_nullable,column_default FROM information_schema.columns WHERE table_schema='citymanager_public_test' AND table_name IN ('city_server_heads','city_server_management_installation') ORDER BY table_name,ordinal_position")).rows,
  constraints:(await c.query("SELECT rel.relname,con.conname,pg_get_constraintdef(con.oid) AS definition FROM pg_constraint con JOIN pg_class rel ON rel.oid=con.conrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE ns.nspname='citymanager_public_test' AND rel.relname IN ('city_server_heads','city_server_management_installation') ORDER BY rel.relname,con.conname")).rows,
  indexes:(await c.query("SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='citymanager_public_test' AND tablename IN ('city_server_heads','city_server_management_installation') ORDER BY tablename,indexname")).rows,
  triggers:(await c.query("SELECT rel.relname,pg_get_triggerdef(t.oid) AS definition FROM pg_trigger t JOIN pg_class rel ON rel.oid=t.tgrelid JOIN pg_namespace ns ON ns.oid=rel.relnamespace WHERE NOT t.tgisinternal AND ns.nspname='citymanager_public_test' AND rel.relname IN ('city_server_heads','city_server_management_installation') ORDER BY rel.relname,t.tgname")).rows
 }));
 const inspectHead=async c=>{
  if(await inspect(c)!=='installed')throw Error('base-save-schema-required');
  const required=(await c.query("SELECT table_name,column_name,data_type FROM information_schema.columns WHERE table_schema='citymanager_public_test' AND ((table_name='listings' AND column_name IN ('seller_id','status')) OR (table_name='delivery_receipts' AND column_name IN ('buyer_id','acknowledged_at'))) ORDER BY table_name,column_name")).rows;
  const expected={'listings.seller_id':'uuid','listings.status':'text','delivery_receipts.buyer_id':'uuid','delivery_receipts.acknowledged_at':'timestamp with time zone'};
  if(required.length!==4||required.some(r=>expected[r.table_name+'.'+r.column_name]!==r.data_type))throw Error('market-obligation-contract-unverified');
  const found=(await c.query("SELECT relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='citymanager_public_test' AND relname IN ('city_server_heads','city_server_management_installation')")).rows;
  if(!found.length)return 'absent';if(found.length!==2)throw Error('partial-management-schema');
  const records=(await c.query('SELECT version,migration_hash,schema_hash FROM citymanager_public_test.city_server_management_installation')).rows;
  const fk=(await c.query("SELECT confrelid='citymanager_public_test.accounts'::regclass AS correct FROM pg_constraint WHERE contype='f' AND conrelid='citymanager_public_test.city_server_heads'::regclass")).rows;
  if(records.length!==1||records[0].version!==1||records[0].migration_hash!==migrationHash||records[0].schema_hash!==await headFingerprint(c)||fk.length!==1||!fk[0].correct)throw Error('management-schema-fingerprint-mismatch');
  return 'installed';
 };
 if(mode==='plan'||mode==='rollback-safe'){
  const c=await pool.connect();try{const state=await inspectHead(c);let safe=true;if(state==='installed')safe=!(await c.query('SELECT EXISTS(SELECT 1 FROM citymanager_public_test.city_server_heads) AS deleted')).rows[0].deleted;
   if(mode==='rollback-safe'&&!safe)throw Error('old-writer-rollback-forbidden');
   console.log(JSON.stringify({ok:true,targetSchema:TARGET_SCHEMA,schema:state,rollbackSafe:safe,migrationHash,obligationContractVerified:true}));
  }finally{c.release();}
 }else{
  if(mode==='apply')await module.tx(async c=>{
   await c.query('SET LOCAL search_path = citymanager_public_test, pg_catalog');await c.query("SET LOCAL lock_timeout='5s'");await c.query("SET LOCAL statement_timeout='30s'");
   await c.query("SELECT pg_advisory_xact_lock(hashtext('CityManager-server-save-install-v1'))");
   if(await inspectHead(c)==='installed')return;
   await c.query(migration);
   await c.query('CREATE TABLE city_server_management_installation(version integer PRIMARY KEY,migration_hash text NOT NULL,schema_hash text NOT NULL,applied_at timestamptz NOT NULL DEFAULT now())');
   await c.query('INSERT INTO city_server_management_installation(version,migration_hash,schema_hash) VALUES(1,$1,$2)',[migrationHash,await headFingerprint(c)]);
   if(await inspectHead(c)!=='installed')throw Error('management-post-migration-check-failed');
  });
  const c=await pool.connect();try{if(await inspectHead(c)!=='installed')throw Error('management-schema-required');}finally{c.release();}
  const {randomUUID}=await import('node:crypto');const owner=randomUUID();
  if((await pool.query('SELECT 1 FROM citymanager_public_test.accounts WHERE id=$1',[owner])).rowCount)throw Error('synthetic-owner-collision');
  const {createServerCityService}=await import(pathToFileURL(path.join(bundle,'service.mjs')).href);const {createServerCityPgStore}=await import(pathToFileURL(path.join(bundle,'pg-store.mjs')).href);
  const service=createServerCityService(createServerCityPgStore({pool,tx:module.tx}));if(await service.read(owner)!==null)throw Error('nonexistent-owner-read-failed');
  if(mode==='apply'){
   const sentinel=Error('management-fixture-rollback');let finished=false;
   try{await module.tx(async c=>{
    await c.query("SET LOCAL lock_timeout='5s'");await c.query("SET LOCAL statement_timeout='30s'");
    await c.query('CREATE TEMP TABLE accounts(id uuid PRIMARY KEY) ON COMMIT DROP');
    await c.query('SET LOCAL search_path = pg_temp, pg_catalog');
    for(const table of ['city_server_snapshots','city_server_requests','city_server_archives','city_server_archive_sources','city_server_heads'])await c.query(`CREATE TEMP TABLE ${table} (LIKE citymanager_public_test.${table} INCLUDING ALL) ON COMMIT DROP`);
    await c.query('CREATE TEMP TABLE listings(seller_id uuid,status text) ON COMMIT DROP');await c.query('CREATE TEMP TABLE delivery_receipts(buyer_id uuid,acknowledged_at timestamptz) ON COMMIT DROP');
    const fixtureOwner=randomUUID(),oldCity=randomUUID(),newCity=randomUUID(),firstKey=randomUUID();await c.query('INSERT INTO pg_temp.accounts(id) VALUES($1)',[fixtureOwner]);
    const fixture=createServerCityService(createServerCityPgStore({pool:{query:(...a)=>c.query(...a)},tx:fn=>fn(c)}));
    const meta={name:'Temporary lifecycle fixture',population:0,tick:0},raw='{"version":23,"tick":0}';
    const first={action:'create',cityId:oldCity,raw,metadata:meta};await fixture.mutate(fixtureOwner,firstKey,first);
    await fixture.mutate(fixtureOwner,randomUUID(),{action:'save',cityId:oldCity,expectedRevision:1,raw:raw+' ',metadata:meta});
    const deleted=await fixture.mutate(fixtureOwner,randomUUID(),{action:'delete',cityId:oldCity,expectedRevision:2});
    if(!deleted.deleted||deleted.revision!==3||(await fixture.listArchives(fixtureOwner)).length!==2)throw Error('fixture-trash-failed');
    let fenced=false;try{await fixture.mutate(fixtureOwner,firstKey,first);}catch(e){if(e.status!==409)throw e;fenced=true;}if(!fenced)throw Error('fixture-receipt-fence-failed');
    const fresh=JSON.stringify({version:23,tick:0,market:{version:10,rulesVersion:'chain-5',guestId:fixtureOwner,cityId:newCity,operations:[],escrow:[],receipts:{},seq:'0'}});
    const result=await fixture.mutate(fixtureOwner,randomUUID(),{action:'create',cityId:newCity,expectedRevision:3,raw:fresh,metadata:meta});
    if(result.revision!==4||(await fixture.read(fixtureOwner)).cityId!==newCity)throw Error('fixture-recreate-failed');
    finished=true;throw sentinel;
   });}catch(e){if(e!==sentinel)throw e;}
   if(!finished)throw Error('fixture-not-finished');
   const verify=await pool.connect();try{if(await inspectHead(verify)!=='installed')throw Error('post-fixture-schema-drift');}finally{verify.release();}
  }
  console.log(JSON.stringify({ok:true,targetSchema:TARGET_SCHEMA,schema:'installed',migrationHash,readback:'nonexistent-owner-null',temporaryLifecycleRollback:mode==='apply',playerDataWritten:false}));
 }
}catch(error){console.error(JSON.stringify({ok:false,code:typeof error?.code==='string'?error.code:'validation-failed',validation:/^[a-z][a-z-]+$/.test(error?.message??'')?error.message:undefined}));process.exitCode=1;}finally{if(pool)await pool.end();}
