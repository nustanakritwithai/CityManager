# CityManager recoverable save management — existing VPS upgrade

Scope approved: replace only service.mjs and pg-store.mjs, update only their two existing hashes in startup.ps1, add city state/version metadata in citymanager_public_test, and restart only the existing API task. Server.js, Pages authentication, router, Caddy, account credentials, wallet/ledger and public schema remain unchanged. The integrity guard is preserved. This installer never deletes a player's city.

Verify the published ZIP SHA256 and extract into a fresh directory. In existing Windows PowerShell:

```powershell
& '.\CityManager-Save-Management\Update-CitySaveManagement.ps1' -Mode Apply
```

Use -Mode Plan alone for read-only runtime/database checks plus local staging (no live config, schema or process changes). Apply repeats checks and backups before changes. It verifies the runtime schema and existing owner foreign keys, known base-save schema, required market-obligation columns, exact seven original integrity-guard entries, Node entry, sole loopback4317 process and existing startup task. Process identity is captured/rechecked in the same execution; process working directory is not falsely claimed to be measured by CIM.

Before stopping API, it performs atomic create/replace/restore tests on both volumes, verifies all backups, applies additive head+version-marker tables transactionally, and exercises create/save/delete/fresh-create/receipt fencing only on TEMP fixture tables followed by forced rollback. No real account, city or receipt is written in the fixture. Missing/unknown schema contracts stop before source replacement.

New behavior is user-controlled: explicit delete CAS archives current+previous exact city bytes with provenance, then publishes a persistent tombstone. Old receipts and stale tabs cannot restore a deleted lifecycle. Explicit new-city creation CAS uses a new cityId and pristine disabled-market journal; old journal stays archived, and account wallet/ledger are not reset. Outstanding or unverified financial obligations reject deletion. No permanent purge endpoint exists.

Rollback limitation: after the API is quiesced, OLD backend code may be restored ONLY if there are NO persistent head rows. Even an active head makes legacy snapshot-only writers unsafe. If any head exists, old-code rollback is refused; the API may remain stopped and forward recovery is required. Never delete/reset heads to force rollback. Additive tables, archives and backups are retained in every case.

Cloud evidence: 18 service/client lifecycle tests plus 7 focused PG-adapter/installer/guard-patch mock tests and Node syntax checks passed. Real Windows PowerShell/Caddy/PostgreSQL execution is not claimed; this user-run installer supplies actual preflight/TEMP rollback evidence. After backend success, release the separately reviewed frontend and verify the user's explicit confirmation workflow. Do not run retired public-schema installers.
