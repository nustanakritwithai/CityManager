-- Additive only, executed in the verified citymanager_public_test transaction.
-- Existing immutable archives hold deleted current+previous raw snapshots.
CREATE TABLE city_server_heads (
 account_id uuid PRIMARY KEY REFERENCES accounts(id),
 city_id uuid NOT NULL, revision bigint NOT NULL CHECK(revision>0),
 deleted boolean NOT NULL, last_deleted_revision bigint NOT NULL DEFAULT 0,
 archive_hash text,
 CHECK(last_deleted_revision>=0 AND last_deleted_revision<=revision),
 CHECK((deleted AND archive_hash IS NOT NULL AND length(archive_hash)=64 AND last_deleted_revision=revision) OR (NOT deleted AND archive_hash IS NULL))
);
