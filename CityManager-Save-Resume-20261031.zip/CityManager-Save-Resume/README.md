# Resume after verified original API recovery

This corrected package pins recovered PID 11936 and creation 2026-10-31T17:05:08.4591060+07:00. It retains the original Plan report, requires original server/pages hashes, accepts only the exact three staged backend modules and validated installed DB schema, and runs actual Windows atomic create/replace/restore testing before any DB/process changes. Replacement uses a unique nonempty backup path; backups and additive tables remain. Do not retry the superseded Apply ZIP.

# CityManager existing-login save API — reviewed Apply candidate

User-authorized scope: add owner-scoped save/load/archive APIs to the existing Guest cookie/Pages PKCE login, add separate tables, back up touched source and restart only the existing API. No administrator grants, market enablement, new accounts/providers/costs or old-save deletion.

## Apply from the verified bundle

Run in the existing Windows PowerShell session after verifying the published ZIP SHA256:

```powershell
& '.\installer\Install-CitySave.ps1' -Mode Apply -PlanDirectory 'C:\Users\ADMINI~1\AppData\Local\Temp\2\city-save-plan-20261031-165150'
```

No execution-policy change is included. Do not bypass a failed preflight.

The installer pins the user's original server/pages-auth SHA256 values and the reviewed startup-script hash. The relative Node entry is operationally bound to reviewed PID6724, creation time, exact executable/args, sole loopback port4317, static startup directory and existing scheduled task. It explicitly DOES NOT claim CIM measured that process's working directory. Every relevant fact is rechecked before stopping the original process; new process identity is bound to the tracked existing-task start.

Steps: verify bundle/Plan/source/startup; regenerate exact candidate; verify both new backups; run a bounded real-PostgreSQL TEMP-only fixture inside a transaction forced to roll back; apply additive schema transaction; stop only the verified API; atomically install hash-checked source; restart the unchanged existing task; verify health200 and unauthenticated city-save401. The fixture never touches real accounts or player data. A fixture failure stops before production schema or process changes.

On source/start/health failure, restore only original verified source and restart the original task. Additive tables and committed save data remain; there is no DROP/reset/down-migration. If external source/process drift makes rollback unsafe, stop and use the printed backup path for review rather than killing other processes or deleting data.

## Verification limits

Cloud Node/mock tests passed; read-only Windows/PG preflight passed with the reported relative-entry limitation. The TEMP-only real-PG write test and Apply have not run yet; they execute locally as part of this authorized installer. Existing-account browser save/load and deployed frontend integration still need verification after backend installation. Successful backend installation alone does not mean browser saves have switched over.

Storage bounds: 8MiB raw city, 512MiB owner raw storage cap, current+previous working copies, immutable deduplicated migration archives, compact idempotency receipts capped at100,000. Quota failures preserve existing data and never fall back to browser saving. Market journals remain frozen while trading is off.

The existing protected DATABASE_URL file may be read locally into the helper process if needed; its value is never printed or persisted. No credentials are included in this bundle.
