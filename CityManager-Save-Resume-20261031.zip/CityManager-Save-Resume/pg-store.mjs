const decode=row=>{if(!row)return null;const revision=Number(row.revision);if(!Number.isSafeInteger(revision)||revision<1)throw Error('invalid-stored-revision');return {owner:row.account_id,cityId:row.city_id,revision,raw:row.raw,rawHash:row.raw_hash,metadata:row.metadata};};
const currentSQL='SELECT account_id,city_id,revision,raw,raw_hash,metadata FROM city_server_snapshots WHERE account_id=$1 ORDER BY revision DESC LIMIT 1';
export function createServerCityPgStore({pool,tx}){return {
 read:async owner=>decode((await pool.query(currentSQL,[owner])).rows[0]),
 transaction(owner,work){return tx(async client=>{
  const lock=await client.query('SELECT id FROM accounts WHERE id=$1 FOR UPDATE',[owner]);if(!lock.rowCount)throw Object.assign(Error('guest-required'),{status:401});
  return work({
   bytes:async()=>Number((await client.query('SELECT COALESCE((SELECT sum(octet_length(raw)) FROM city_server_snapshots WHERE account_id=$1),0)+COALESCE((SELECT sum(octet_length(raw)) FROM city_server_archives WHERE account_id=$1),0) AS bytes',[owner])).rows[0].bytes),
   hasArchive:async h=>(await client.query('SELECT 1 FROM city_server_archives WHERE account_id=$1 AND raw_hash=$2',[owner,h])).rowCount>0,
   current:async()=>decode((await client.query(currentSQL,[owner])).rows[0]),
   requestCount:async()=>Number((await client.query('SELECT count(*) AS count FROM city_server_requests WHERE account_id=$1',[owner])).rows[0].count),
   request:async id=>{const r=(await client.query('SELECT payload_hash,response FROM city_server_requests WHERE account_id=$1 AND request_id=$2',[owner,id])).rows[0];return r?{payloadHash:r.payload_hash,response:r.response}:null;},
   record:(id,h,response)=>{const {raw,...receipt}=response;return client.query('INSERT INTO city_server_requests(account_id,request_id,payload_hash,response) VALUES($1,$2,$3,$4)',[owner,id,h,JSON.stringify(receipt)]);},
   publish:async v=>{await client.query('INSERT INTO city_server_snapshots(account_id,revision,city_id,raw,raw_hash,metadata) VALUES($1,$2,$3,$4,$5,$6)',[owner,v.revision,v.cityId,v.raw,v.rawHash,JSON.stringify(v.metadata)]);await client.query('DELETE FROM city_server_snapshots WHERE account_id=$1 AND revision<$2',[owner,v.revision-1]);},
   archive:async(h,raw,source)=>{await client.query('INSERT INTO city_server_archives(account_id,raw_hash,raw) VALUES($1,$2,$3) ON CONFLICT DO NOTHING',[owner,h,raw]);const stored=(await client.query('SELECT raw FROM city_server_archives WHERE account_id=$1 AND raw_hash=$2',[owner,h])).rows[0];if(stored?.raw!==raw)throw Error('archive-hash-collision');await client.query('INSERT INTO city_server_archive_sources(account_id,raw_hash,source) VALUES($1,$2,$3) ON CONFLICT DO NOTHING',[owner,h,source]);}
  });
 });},
 async listArchives(owner){const r=await pool.query('SELECT a.raw_hash AS hash,a.created_at AS "createdAt",array_agg(s.source ORDER BY s.source) AS sources FROM city_server_archives a JOIN city_server_archive_sources s USING(account_id,raw_hash) WHERE a.account_id=$1 GROUP BY a.raw_hash,a.created_at ORDER BY a.created_at,a.raw_hash',[owner]);return r.rows;},
 async readArchive(owner,h){const r=await pool.query('SELECT a.raw_hash AS hash,a.raw,array_agg(s.source ORDER BY s.source) AS sources FROM city_server_archives a JOIN city_server_archive_sources s USING(account_id,raw_hash) WHERE a.account_id=$1 AND a.raw_hash=$2 GROUP BY a.raw_hash,a.raw',[owner,h]);return r.rows[0]??null;}
};}
