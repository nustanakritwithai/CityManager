[CmdletBinding()]
param(
 [ValidateSet('Plan','Apply')][string]$Mode='Plan',
 [string]$Root='C:\Users\Administrator\Documents\Codex\2026-10-26\task-8\market-server-release-6269011',
 [string]$PlanDirectory
)
$ErrorActionPreference='Stop'
$Bundle=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$ExpectedRoot='C:\Users\Administrator\Documents\Codex\2026-10-26\task-8\market-server-release-6269011'
$Startup='C:\ProgramData\CityManagerMarket\startup.ps1'
$TaskName='CityManager-Market-Boot'
$ApprovedStartupHash='c7139d654e3ed106680fe2db1b8701f3a2cfd08ca906e541d7a16c6fce176ee3'
$ApprovedNode='C:\Program Files\nodejs\node.exe'
$script:RelativeBindingRecord=$null
$script:RestartStartedAt=$null
$Root=(Resolve-Path $Root).Path
if($Root -ne $ExpectedRoot){throw 'Wrong runtime root; stopped.'}
function HashFile([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function CheckBundle {
 $manifest=Get-Content -LiteralPath (Join-Path $Bundle 'bundle-manifest.json') -Raw | ConvertFrom-Json
 $roster=@('README.md','migration.sql','pg-store.mjs','router.mjs','service.mjs','installer/Install-CitySave.ps1','installer/database-check.mjs','installer/patch-runtime.mjs')|Sort-Object
 if($manifest.version -ne 1 -or (($manifest.files.PSObject.Properties.Name|Sort-Object)-join ',') -ne ($roster-join ',')){throw 'Unknown full bundle manifest roster/version.'}
 foreach($p in $manifest.files.PSObject.Properties){
  if($p.Name -match '(^[\\/]|\.\.|:)' -or $p.Value -notmatch '^[a-f0-9]{64}$'){throw 'Unsafe bundle path/hash.'}
  if((HashFile (Join-Path $Bundle $p.Name)) -ne $p.Value){throw "Bundle hash mismatch: $($p.Name)"}
 }
 return $manifest
}
function RunNode([string[]]$Arguments){
 $previous=$ErrorActionPreference
 try{$ErrorActionPreference='Continue';$result=& $script:Node @Arguments 2>&1;$exitCode=$LASTEXITCODE}finally{$ErrorActionPreference=$previous}
 if($exitCode -ne 0){
  $safe=''
  if([IO.Path]::GetFileName($Arguments[0]) -eq 'database-check.mjs'){
   try{$detail=($result -join "`n")|ConvertFrom-Json;if($detail.code -match '^[A-Za-z0-9-]+$'){$safe+=' code='+$detail.code};if($detail.validation -match '^[a-z-]+$'){$safe+=' validation='+$detail.validation}}catch{}
  }
  throw ('Node validation stopped'+$safe+'. No credentials printed; inspect the stated rollback result.')
 }
 return ($result -join "`n")
}
function Health {
 $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4317/health' -TimeoutSec 3
 if($r.StatusCode -ne 200 -or -not (($r.Content|ConvertFrom-Json).ok)){throw 'API health check failed.'}
}
function Runtime {
 $ports=@(Get-NetTCPConnection -LocalPort 4317 -State Listen)
 $ids=@($ports|Select-Object -ExpandProperty OwningProcess -Unique)
 if($ids.Count -ne 1){throw 'Expected exactly one process listening on port4317.'}
 if(@($ports|Where-Object {$_.LocalAddress -notin @('127.0.0.1','::1')}).Count){throw 'API listener is not loopback-only.'}
 $p=Get-CimInstance Win32_Process -Filter "ProcessId=$($ids[0])"
 if(-not $p -or $p.ExecutablePath -ne $ApprovedNode){throw 'Port4317 is not the specifically verified Node executable.'}
 $entry=(Join-Path $Root 'src\server.js').ToLowerInvariant()
 $exePattern='(?:'+[regex]::Escape($p.ExecutablePath.ToLowerInvariant())+'|node(?:\.exe)?)'
 $commandPattern='^\s*"?'+$exePattern+'"?\s*"?'+[regex]::Escape($entry)+'"?\s*$'
 $observed=$p.CommandLine.Replace('/','\').ToLowerInvariant()
 $relativePattern='^\s*"?'+$exePattern+'"?\s*"?(?:\.\\)?src\\server\.js"?\s*$'
 if($observed -notmatch $commandPattern){
  if($observed -notmatch $relativePattern -or $p.ExecutablePath -ne $ApprovedNode -or (HashFile $Startup) -ne $ApprovedStartupHash){throw 'Unexpected runtime command/startup identity; stopped.'}
  $bound=$false
  if($script:RelativeBindingRecord){$createdMatches=if($script:RelativeBindingRecord.CreatedISO){([datetime]$p.CreationDate).ToUniversalTime().Ticks -eq ([DateTimeOffset]::Parse($script:RelativeBindingRecord.CreatedISO,[Globalization.CultureInfo]::InvariantCulture)).UtcDateTime.Ticks}else{[string]$p.CreationDate -eq [string]$script:RelativeBindingRecord.Created};$bound=([int]$p.ProcessId -eq [int]$script:RelativeBindingRecord.Pid -and $createdMatches)}
  if($script:RestartStartedAt){$bound=$bound -or ([datetime]$p.CreationDate).ToUniversalTime() -ge $script:RestartStartedAt}
  if(-not $bound){throw 'Relative-entry process is outside the reviewed PID/creation/startup contract.'}
  # This is operational service binding, NOT a claim that CIM measured process cwd.
 }

 return @{Pid=[int]$p.ProcessId;Created=[string]$p.CreationDate;Executable=$p.ExecutablePath;CommandHash=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($p.CommandLine))).Replace('-','').ToLowerInvariant())}
}
function CheckTask {
 $tasks=@(Get-ScheduledTask -TaskName $TaskName)
 if($tasks.Count -ne 1 -or @($tasks[0].Actions).Count -ne 1){throw 'Expected the single existing startup task/action.'}
 $a=$tasks[0].Actions[0]
 if([IO.Path]::GetFileName($a.Execute) -notin @('powershell.exe','pwsh.exe')){throw 'Unknown task executable; stopped.'}
 $taskPattern='^\s*(?:(?:-NoProfile|-NoLogo|-NonInteractive)\s+|-ExecutionPolicy\s+(?:Bypass|RemoteSigned|AllSigned|Restricted|Unrestricted)\s+|-WindowStyle\s+(?:Hidden|Normal|Minimized|Maximized)\s+)*-File\s+"?'+[regex]::Escape($Startup)+'"?\s*$'
 if(-not $a.Arguments -or $a.Arguments -notmatch $taskPattern){throw 'Existing task has an unverified command/argument shape.'}
 if(-not (Test-Path -LiteralPath $Startup -PathType Leaf)){throw 'Existing startup script missing.'}
 # Inspect text in memory only. Never print its contents or environment values.
 $text=[IO.File]::ReadAllText($Startup)
 if(-not $text.ToLowerInvariant().Contains($Root.ToLowerInvariant())){throw 'Startup script does not identify the exact runtime root.'}
 return @{TaskPath=$tasks[0].TaskPath;StartupHash=(HashFile $Startup);ActionHash=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes(($a.Execute+' '+$a.Arguments)))).Replace('-','').ToLowerInvariant())}
}
function StopExact($snapshot,$task){
 $nowTask=CheckTask
 if($nowTask.StartupHash -ne $task.StartupHash -or $nowTask.ActionHash -ne $task.ActionHash -or $nowTask.TaskPath -ne $task.TaskPath){throw 'Startup task changed before stop; refused.'}
 $nowRuntime=Runtime
 if($nowRuntime.Pid -ne $snapshot.Pid -or $nowRuntime.Created -ne $snapshot.Created -or $nowRuntime.CommandHash -ne $snapshot.CommandHash -or $nowRuntime.Executable -ne $snapshot.Executable){throw 'API/process ownership changed before stop; refused.'}
 $before=Get-CimInstance Win32_Process -Filter "ProcessId=$($snapshot.Pid)"
 if(-not $before -or [string]$before.CreationDate -ne $snapshot.Created){throw 'Process changed before stop; refused.'}
 $beforeHash=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($before.CommandLine))).Replace('-','').ToLowerInvariant())
 if($beforeHash -ne $snapshot.CommandHash){throw 'Process command changed before stop; refused.'}
 Stop-ScheduledTask -TaskName $TaskName -TaskPath $task.TaskPath -ErrorAction SilentlyContinue
 Start-Sleep -Milliseconds 300
 $p=Get-CimInstance Win32_Process -Filter "ProcessId=$($snapshot.Pid)"
 if($p){
  $h=([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($p.CommandLine))).Replace('-','').ToLowerInvariant())
  if([string]$p.CreationDate -ne $snapshot.Created -or $h -ne $snapshot.CommandHash){throw 'Process changed; refusing to stop it.'}
  Stop-Process -Id $snapshot.Pid
 }
 for($i=0;$i -lt 30;$i++){if(-not (Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue)){return};Start-Sleep -Milliseconds 200}
 throw 'Verified API did not stop.'
}
function StartExisting($task){
 $now=CheckTask
 if($now.StartupHash -ne $task.StartupHash -or $now.ActionHash -ne $task.ActionHash -or $now.TaskPath -ne $task.TaskPath){throw 'Startup contract changed; refused restart.'}
 $state=Get-ScheduledTask -TaskName $TaskName -TaskPath $task.TaskPath
 if($state.State -eq 'Running'){
  if(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue){throw 'API is already listening; refused duplicate start.'}
  Stop-ScheduledTask -TaskName $TaskName -TaskPath $task.TaskPath
  for($i=0;$i -lt 20;$i++){if((Get-ScheduledTask -TaskName $TaskName -TaskPath $task.TaskPath).State -ne 'Running'){break};Start-Sleep -Milliseconds 250}
  if((Get-ScheduledTask -TaskName $TaskName -TaskPath $task.TaskPath).State -eq 'Running'){throw 'Existing startup task did not stop.'}
 }
 if(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue){throw 'Port4317 became occupied before start; refused duplicate API launch.'}
 $script:RestartStartedAt=(Get-Date).ToUniversalTime()
 Start-ScheduledTask -TaskName $TaskName -TaskPath $task.TaskPath
 for($i=0;$i -lt 60;$i++){try{Health;[void](Runtime);return}catch{Start-Sleep -Seconds 1}}
 throw 'Existing API failed readiness within60seconds.'
}
function WriteAtomic([string]$Source,[string]$Destination,[string]$ExpectedHash){
 if($ExpectedHash -notmatch '^[a-f0-9]{64}$'){throw 'Missing atomic-write expected hash.'}
 $temp=$Destination+'.city-save-'+[Guid]::NewGuid().ToString('N')+'.tmp'
 Copy-Item -LiteralPath $Source -Destination $temp
 if((HashFile $temp) -ne $ExpectedHash){Remove-Item -LiteralPath $temp;throw 'Staged copy hash changed; no destination replaced.'}
 if(Test-Path -LiteralPath $Destination){
  # Windows PowerShell can coerce $null string arguments into an illegal empty path.
  $replacementBackup=$Destination+'.city-save-replaced-'+[Guid]::NewGuid().ToString('N')+'.bak'
  if(Test-Path -LiteralPath $replacementBackup){throw 'Replacement backup unexpectedly exists.'}
  [IO.File]::Replace($temp,$Destination,$replacementBackup)
 }else{[IO.File]::Move($temp,$Destination)}
 if((HashFile $Destination) -ne $ExpectedHash){throw 'Atomic destination verification failed.'}
}
function CheckStagedModules {
 $directory=Join-Path $Root 'src\city-saves'
 if(-not (Test-Path -LiteralPath $directory)){return $false}
 $directoryItem=Get-Item -LiteralPath $directory -Force
 if(-not $directoryItem.PSIsContainer -or ($directoryItem.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Partial module directory is not an ordinary directory.'}
 $files=@(Get-ChildItem -LiteralPath $directory -Force)
 if($files.Count -ne 3 -or (($files.Name|Sort-Object)-join ',') -ne 'pg-store.mjs,router.mjs,service.mjs' -or @($files|Where-Object {$_.PSIsContainer -or ($_.Attributes -band [IO.FileAttributes]::ReparsePoint)}).Count){throw 'Unknown partial module directory; no overwrite allowed.'}
 foreach($name in @('service.mjs','pg-store.mjs','router.mjs')){if((HashFile (Join-Path $directory $name)) -ne $bundleManifest.files.PSObject.Properties[$name].Value){throw 'Partial module bytes differ from exact reviewed payload.'}}
 return $true
}
function TestAtomicWrite {
 # Exercise this exact .NET/PowerShell/filesystem combination without touching live source.
 $testDir=Join-Path (Join-Path $Root 'src') ('city-save-atomic-test-'+[Guid]::NewGuid().ToString('N'))
 [void](New-Item -ItemType Directory -Path $testDir)
 $original=Join-Path $testDir 'original.txt';$next=Join-Path $testDir 'next.txt';$destination=Join-Path $testDir 'destination.txt'
 [IO.File]::WriteAllText($original,'city-save-original');[IO.File]::WriteAllText($next,'city-save-next')
 WriteAtomic $original $destination (HashFile $original)
 WriteAtomic $next $destination (HashFile $next)
 WriteAtomic $original $destination (HashFile $original)
 Write-Output 'Actual Windows atomic create/replace/restore self-test passed; isolated fixture retained.'
}
$bundleManifest=CheckBundle
# Accept only the reviewed operational relative-startup evidence, without changing its cwd=false fact.
$earlyInstalled=Join-Path $Root 'src\city-saves\install-manifest.json'
if(Test-Path -LiteralPath $earlyInstalled){
 $prior=Get-Content -LiteralPath $earlyInstalled -Raw|ConvertFrom-Json
 $expected=@('src/city-saves/pg-store.mjs','src/city-saves/router.mjs','src/city-saves/service.mjs','src/pages-auth.js','src/server.js')
 if($prior.version -ne 1 -or (($prior.installed.PSObject.Properties.Name|Sort-Object)-join ',') -ne ($expected-join ',') -or $prior.bindingBasis -ne 'reviewed-relative-startup-contract' -or $prior.startupHash -ne $ApprovedStartupHash){throw 'Unknown installed binding manifest.'}
 foreach($property in $prior.installed.PSObject.Properties){if((HashFile (Join-Path $Root $property.Name)) -ne $property.Value){throw 'Installed source drift.'}}
 $script:RelativeBindingRecord=$prior.runtime
}elseif($Mode -eq 'Apply' -and $PlanDirectory){
 $earlyReport=Get-Content -LiteralPath (Join-Path $PlanDirectory 'preflight-report.json') -Raw|ConvertFrom-Json
 if($earlyReport.result -ne 'PLAN_REVIEW_REQUIRED' -or $earlyReport.mode -ne 'PLAN_ONLY' -or $earlyReport.runtimeEntryMode -ne 'relative' -or $earlyReport.runtimeDirectoryVerified -ne $false -or $earlyReport.checksPassed -ne $true -or $earlyReport.startupWorkingDirectoryMatches -ne $true -or $earlyReport.startupDeclaresRoot -ne $true -or $earlyReport.startupHash -ne $ApprovedStartupHash -or $earlyReport.pid -ne 6724 -or $earlyReport.processCreation -ne '10/31/2026 03:14:19' -or $earlyReport.root -ne $Root -or $earlyReport.task -ne $TaskName -or $earlyReport.taskPath -ne '\'){throw 'Report does not match the specifically reviewed relative-startup service contract.'}
 $script:RelativeBindingRecord=@{Pid=11936;CreatedISO='2026-10-31T17:05:08.4591060+07:00'}
}
$live=Runtime;$script:Node=$live.Executable
$task=CheckTask
Health
$version=RunNode -Arguments @('--version')
if($version -notmatch '^v24\.'){throw 'Expected the verified Node24 runtime.'}
$installedPath=Join-Path $Root 'src\city-saves\install-manifest.json'
if(Test-Path -LiteralPath $installedPath){
 $installed=Get-Content -LiteralPath $installedPath -Raw|ConvertFrom-Json
 $roster=@('src/city-saves/pg-store.mjs','src/city-saves/router.mjs','src/city-saves/service.mjs','src/pages-auth.js','src/server.js')
 if($installed.version -ne 1 -or (($installed.installed.PSObject.Properties.Name|Sort-Object)-join ',') -ne ($roster-join ',')){throw 'Unknown installed manifest roster/version.'}
 foreach($p in $installed.installed.PSObject.Properties){if((HashFile (Join-Path $Root $p.Name)) -ne $p.Value){throw 'Installed files changed; manual review required.'}}
 foreach($name in @('service.mjs','pg-store.mjs','router.mjs')){if((HashFile (Join-Path $Root ('src\city-saves\'+$name))) -ne (HashFile (Join-Path $Bundle $name))){throw 'Different backend payload is already installed.'}}
 [void](RunNode -Arguments @((Join-Path $PSScriptRoot 'database-check.mjs'),'plan',$Root,$Bundle,$bundleManifest.files.'migration.sql'))
 Write-Output 'Exact installed city-save version verified; no files, schema or processes changed.';exit 0
}
$pinned=@{'src/server.js'='8affc2803830b8333caa4595dbf0a80fd8a4609e07c40e16ce1567ac4fdc4bb3';'src/pages-auth.js'='66c98ff9fcc434038982a062178532921825274f7097df65bfeca262ae14662f'}
foreach($name in $pinned.Keys){if((HashFile (Join-Path $Root $name)) -ne $pinned[$name]){throw 'Source differs from user-verified backup hashes; stopped.'}}
$stagedModules=CheckStagedModules
if($Mode -eq 'Plan'){
 if(-not $PlanDirectory){$PlanDirectory=Join-Path (Split-Path $Root -Parent) ('city-save-plan-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))}
 if(Test-Path -LiteralPath $PlanDirectory){throw 'PlanDirectory already exists; choose a new directory.'}
 [void](New-Item -ItemType Directory -Path $PlanDirectory)
 [void](RunNode -Arguments @((Join-Path $PSScriptRoot 'patch-runtime.mjs'),'plan',$Root,$PlanDirectory))
 [void](RunNode -Arguments @('--check',(Join-Path $PlanDirectory 'server.js')))
 [void](RunNode -Arguments @('--check',(Join-Path $PlanDirectory 'pages-auth.js')))
 $db=RunNode -Arguments @((Join-Path $PSScriptRoot 'database-check.mjs'),'plan',$Root,$Bundle,$bundleManifest.files.'migration.sql')
 @{version=1;root=$Root;live=$live;task=$task;bundleHash=(HashFile (Join-Path $Bundle 'bundle-manifest.json'));database=($db|ConvertFrom-Json)}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $PlanDirectory 'preflight.json') -Encoding UTF8
 Write-Output "Plan passed. No live source, schema or process changed. Review directory: $PlanDirectory"
 Write-Output "Apply using the same bundle: .\installer\Install-CitySave.ps1 -Mode Apply -PlanDirectory `"$PlanDirectory`""
 exit 0
}
if(-not $PlanDirectory){throw 'Apply requires the reviewed PlanDirectory.'}
$plan=Get-Content -LiteralPath (Join-Path $PlanDirectory 'source-plan.json') -Raw|ConvertFrom-Json
$fullPreflight=Join-Path $PlanDirectory 'preflight.json'
$readOnlyPreflight=Join-Path $PlanDirectory 'preflight-report.json'
if(Test-Path -LiteralPath $readOnlyPreflight){
 $reviewed=Get-Content -LiteralPath $readOnlyPreflight -Raw|ConvertFrom-Json
 if($reviewed.runtimeDirectoryVerified -eq $false -and -not $script:RelativeBindingRecord){throw 'Relative runtime binding not reviewed.'}
 if(($reviewed.ok -ne $true -and -not $script:RelativeBindingRecord) -or $reviewed.mode -ne 'PLAN_ONLY' -or $reviewed.root -ne $Root -or $reviewed.health -ne 200 -or $reviewed.pagesPreflight -ne 204 -or $reviewed.task -ne $TaskName -or $reviewed.taskPath -ne $task.TaskPath -or $reviewed.startupHash -ne $task.StartupHash -or $reviewed.database.ok -ne $true -or $reviewed.database.database -ne 'cm_market_sandbox' -or $reviewed.database.migrationHash -ne $bundleManifest.files.'migration.sql'){throw 'Plan-only report is incomplete, stale, or targets different runtime/schema.'}
 foreach($name in $pinned.Keys){if($reviewed.sourceHashes.PSObject.Properties[$name].Value -ne $pinned[$name]){throw 'Plan-only source hash differs from reviewed backup.'}}
 # The read-only package differs from this full payload; trust neither its path nor unchecked contents.
 # Actual live source, DB, startup contract, full-payload hashes and regenerated patch are rechecked below.
 $preflight=[pscustomobject]@{version=1;root=$Root;task=$task;bundleHash=(HashFile (Join-Path $Bundle 'bundle-manifest.json'))}
}elseif(Test-Path -LiteralPath $fullPreflight){$preflight=Get-Content -LiteralPath $fullPreflight -Raw|ConvertFrom-Json}else{throw 'Reviewed preflight report is missing.'}
if($plan.version -ne 1 -or (($plan.original.PSObject.Properties.Name|Sort-Object)-join ',') -ne 'package.json,src/db.js,src/pages-auth.js,src/server.js' -or (($plan.candidate.PSObject.Properties.Name|Sort-Object)-join ',') -ne 'src/pages-auth.js,src/server.js'){throw 'Unknown plan version/file roster.'}
if($plan.root -ne $Root -or $preflight.root -ne $Root -or $preflight.version -ne 1){throw 'Wrong plan target.'}
if($preflight.bundleHash -ne (HashFile (Join-Path $Bundle 'bundle-manifest.json'))){throw 'Bundle changed after Plan.'}
if($preflight.task.StartupHash -ne $task.StartupHash -or $preflight.task.ActionHash -ne $task.ActionHash){throw 'Startup contract changed after Plan.'}
foreach($p in $plan.original.PSObject.Properties){if((HashFile (Join-Path $Root $p.Name)) -ne $p.Value){throw "Source changed after Plan: $($p.Name)"}}
foreach($name in @('server.js','pages-auth.js')){if((HashFile (Join-Path $PlanDirectory $name)) -ne $plan.candidate.('src/'+$name)){throw 'Candidate changed after Plan.'}}
$regenerated=Join-Path $PlanDirectory ('revalidated-'+[Guid]::NewGuid().ToString('N'))
[void](RunNode -Arguments @((Join-Path $PSScriptRoot 'patch-runtime.mjs'),'plan',$Root,$regenerated))
foreach($name in @('server.js','pages-auth.js')){if((HashFile (Join-Path $regenerated $name)) -ne (HashFile (Join-Path $PlanDirectory $name))){throw 'Candidate differs from the trusted patch generator.'}}
TestAtomicWrite
$backup=Join-Path (Split-Path $Root -Parent) ('city-save-backup-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
[void](New-Item -ItemType Directory -Path $backup)
foreach($name in @('server.js','pages-auth.js')){Copy-Item -LiteralPath (Join-Path $Root ('src\'+$name)) -Destination (Join-Path $backup $name)}
Copy-Item -LiteralPath (Join-Path $PlanDirectory 'source-plan.json') -Destination (Join-Path $backup 'source-plan.json')
foreach($name in @('server.js','pages-auth.js')){if((HashFile (Join-Path $backup $name)) -ne $plan.original.('src/'+$name)){throw 'New backup hash mismatch; no schema/process changes made.'}}
$changed=$false;$stopped=$false
try{
 Write-Output 'Verified backups and reviewed runtime binding. Checking isolated temporary database transaction.'
 # Bounded real-PG fixture: TEMP tables, same connection, forced rollback, no real accounts.
 [void](RunNode -Arguments @((Join-Path $PSScriptRoot 'database-check.mjs'),'validate',$Root,$Bundle,$bundleManifest.files.'migration.sql'))
 Write-Output 'Temporary transaction validation passed. Applying separate city-save tables atomically.'
 # Additive DB transaction uses the existing db.js pool/tx; no account changes or DROP.
 [void](RunNode -Arguments @((Join-Path $PSScriptRoot 'database-check.mjs'),'apply',$Root,$Bundle,$bundleManifest.files.'migration.sql'))
 foreach($p in $plan.original.PSObject.Properties){if((HashFile (Join-Path $Root $p.Name)) -ne $p.Value){throw 'Live source changed during migration; refusing patch.'}}
 Write-Output 'Rechecking exact API process/startup task, then restarting only that API.'
 $live=Runtime;$stopped=$true;StopExact $live $task
 $moduleDir=Join-Path $Root 'src\city-saves'
 if(-not (CheckStagedModules)){
  [void](New-Item -ItemType Directory -Path $moduleDir)
  foreach($name in @('service.mjs','pg-store.mjs','router.mjs')){WriteAtomic (Join-Path $Bundle $name) (Join-Path $moduleDir $name) $bundleManifest.files.PSObject.Properties[$name].Value}
 }
 $changed=$true
 foreach($name in @('server.js','pages-auth.js')){if((HashFile (Join-Path $Root ('src\'+$name))) -ne $plan.original.('src/'+$name)){throw 'Live source changed immediately before replacement.'};WriteAtomic (Join-Path $PlanDirectory $name) (Join-Path $Root ('src\'+$name)) $plan.candidate.('src/'+$name)}
 [void](RunNode -Arguments @('--check',(Join-Path $Root 'src\server.js')))
 [void](RunNode -Arguments @('--check',(Join-Path $Root 'src\pages-auth.js')))
 StartExisting $task;$stopped=$false
 try{[void](Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4317/v1/city-save' -TimeoutSec 5);throw 'Unauthenticated save access unexpectedly succeeded.'}catch{if(-not $_.Exception.Response -or [int]$_.Exception.Response.StatusCode -ne 401){throw 'City-save unauthenticated rejection not verified.'}}
 $hashes=@{}
 foreach($name in @('src/server.js','src/pages-auth.js','src/city-saves/service.mjs','src/city-saves/pg-store.mjs','src/city-saves/router.mjs')){$hashes[$name]=HashFile (Join-Path $Root $name)}
 @{version=1;installed=$hashes;backup=$backup;bindingBasis='reviewed-relative-startup-contract';runtimeDirectoryVerified=$false;startupHash=$ApprovedStartupHash;runtime=(Runtime);installedAt=(Get-Date).ToUniversalTime().ToString('o')}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $installedPath -Encoding UTF8
 Write-Output "Installed: health200 and unauthenticated city-save401 verified. Backup: $backup"
 Write-Output 'Existing-account browser save/load and Pages preflight verification remain required; no player city was written by this installer.'
}catch{
 $reason=$_.Exception.Message
 if($changed){
  try{
   if(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue){$current=Runtime;$stopped=$true;StopExact $current $task}
   # Validate BOTH destinations and backups before restoring either file.
   foreach($name in @('server.js','pages-auth.js')){
    $destination=Join-Path $Root ('src\'+$name);$h=HashFile $destination
    if($h -ne $plan.candidate.('src/'+$name) -and $h -ne $plan.original.('src/'+$name)){throw 'Newer external source edit detected; automatic restore refused.'}
    if((HashFile (Join-Path $backup $name)) -ne $plan.original.('src/'+$name)){throw 'Backup hash mismatch; restore refused.'}
   }
   foreach($name in @('server.js','pages-auth.js')){if((HashFile (Join-Path $Root ('src\'+$name))) -ne $plan.original.('src/'+$name)){WriteAtomic (Join-Path $backup $name) (Join-Path $Root ('src\'+$name)) $plan.original.('src/'+$name)}}
   StartExisting $task;$stopped=$false
   Write-Warning 'Original source restored and original startup task restarted. Additive city-save tables/data were retained.'
  }catch{Write-Warning "Automatic source rollback needs manual review. Backup: $backup"}
 }elseif($stopped){try{if(Get-NetTCPConnection -LocalPort 4317 -State Listen -ErrorAction SilentlyContinue){Health;[void](Runtime)}else{StartExisting $task}}catch{Write-Warning "Original API restart needs manual review. Backup: $backup"}}
 throw "Installation stopped: $reason. No schema/data deletion was attempted. Backup: $backup"
}
