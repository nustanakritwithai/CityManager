-- REVIEW CANDIDATE ONLY. Never execute against production without rollout approval.
-- Additive isolated names: does not modify accounts, market, prior saves or credentials.
BEGIN;
-- NEW service working copies only: current + previous; no legacy snapshots are affected.
CREATE TABLE city_server_snapshots (
 account_id uuid NOT NULL REFERENCES accounts(id),
 revision bigint NOT NULL CHECK(revision>0), city_id uuid NOT NULL,
 raw text NOT NULL CHECK(octet_length(raw) BETWEEN 1 AND 8388608),
 raw_hash text NOT NULL CHECK(length(raw_hash)=64), metadata jsonb NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(account_id,revision)
);
CREATE TABLE city_server_requests (
 account_id uuid NOT NULL REFERENCES accounts(id), request_id uuid NOT NULL,
 payload_hash text NOT NULL, response jsonb NOT NULL,
 PRIMARY KEY(account_id,request_id)
);
CREATE TABLE city_server_archives (
 account_id uuid NOT NULL REFERENCES accounts(id), raw_hash text NOT NULL CHECK(length(raw_hash)=64),
 raw text NOT NULL CHECK(octet_length(raw) BETWEEN 1 AND 8388608),
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(account_id,raw_hash)
);
CREATE TABLE city_server_archive_sources (
 account_id uuid NOT NULL, raw_hash text NOT NULL, source text NOT NULL CHECK(length(source) BETWEEN 1 AND 512),
 PRIMARY KEY(account_id,raw_hash,source), FOREIGN KEY(account_id,raw_hash) REFERENCES city_server_archives(account_id,raw_hash)
);
CREATE FUNCTION city_server_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'server city records are append-only'; END; $$;
-- Working snapshots rotate atomically; imported archive records remain immutable.
CREATE TRIGGER city_server_archives_immutable BEFORE UPDATE OR DELETE ON city_server_archives FOR EACH ROW EXECUTE FUNCTION city_server_immutable();
COMMIT;
