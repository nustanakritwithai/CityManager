/** Mount at /v1/city-save BEFORE the host's default 32KB JSON parser.
 * guest MUST validate the existing cookie/PKCE credential, setting req.account.id.
 * csrf MUST preserve existing same-origin cookie and narrowly scoped bearer rules.
 * CORS and error response handling remain the host's existing implementation. */
export function serverCityRouter({Router,json,service,guest,csrf}){
 const router=Router();const parse=json({limit:'17mb',strict:true});
 const wrap=fn=>async(req,res,next)=>{try{res.set('Cache-Control','no-store');res.json(await fn(req));}catch(e){next(e);}};
 router.get('/',guest,wrap(req=>service.read(req.account.id)));
 router.post('/',guest,csrf,parse,wrap(req=>service.mutate(req.account.id,req.get('idempotency-key'),req.body)));
 router.get('/archives',guest,wrap(req=>service.listArchives(req.account.id)));
 router.post('/archives',guest,csrf,parse,wrap(req=>service.archive(req.account.id,req.body)));
 router.get('/archives/:hash',guest,wrap(req=>service.readArchive(req.account.id,req.params.hash)));
 return router;
}
