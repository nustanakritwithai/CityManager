[CmdletBinding()]
param([string]$ReportDirectory)
$ErrorActionPreference='Stop'
$Root='C:\Users\Administrator\Documents\Codex\2026-10-26\task-8\market-server-release-6269011'
$Startup='C:\ProgramData\CityManagerMarket\startup.ps1'
$TaskName='CityManager-Market-Boot'
function HashFile([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function RunNode([string[]]$Arguments){$out=& $script:Node @Arguments 2>&1;if($LASTEXITCODE -ne 0){throw 'Node source/database preflight stopped. No live files, schema or process were changed.'};return ($out -join "`n")}
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'bundle-manifest.json') -Raw|ConvertFrom-Json
$roster=@('Plan-CitySave.ps1','README.txt','database-preflight.mjs','patch-plan.mjs')|Sort-Object
if($manifest.version -ne 1 -or (($manifest.files.PSObject.Properties.Name|Sort-Object)-join ',') -ne ($roster-join ',')){throw 'Unknown Plan-only manifest roster.'}
foreach($p in $manifest.files.PSObject.Properties){if((HashFile (Join-Path $PSScriptRoot $p.Name)) -ne $p.Value){throw 'Plan bundle checksum mismatch.'}}
if(-not (Test-Path -LiteralPath $Root -PathType Container)){throw 'Expected existing runtime directory is missing.'}
$pinned=@{'src/server.js'='8affc2803830b8333caa4595dbf0a80fd8a4609e07c40e16ce1567ac4fdc4bb3';'src/pages-auth.js'='66c98ff9fcc434038982a062178532921825274f7097df65bfeca262ae14662f'}
foreach($name in $pinned.Keys){if((HashFile (Join-Path $Root $name)) -ne $pinned[$name]){throw 'Runtime source differs from verified backup hashes; stopped.'}}
if(Test-Path -LiteralPath (Join-Path $Root 'src\city-saves')){throw 'City-save runtime directory already exists; review instead of overwriting.'}
$ports=@(Get-NetTCPConnection -LocalPort 4317 -State Listen)
$ids=@($ports|Select-Object -ExpandProperty OwningProcess -Unique)
if($ids.Count -ne 1 -or @($ports|Where-Object {$_.LocalAddress -notin @('127.0.0.1','::1')}).Count){throw 'Expected exactly one loopback API process.'}
$p=Get-CimInstance Win32_Process -Filter "ProcessId=$($ids[0])"
if(-not $p -or [IO.Path]::GetFileName($p.ExecutablePath) -ne 'node.exe'){throw 'API is not the expected Node process.'}
$entry=(Join-Path $Root 'src\server.js').ToLowerInvariant()
$exePattern='(?:'+[regex]::Escape($p.ExecutablePath.ToLowerInvariant())+'|node(?:\.exe)?)'
$commandPattern='^\s*"?'+$exePattern+'"?\s*"?'+[regex]::Escape($entry)+'"?\s*$'
$relativePattern='^\s*"?'+$exePattern+'"?\s*"?(?:\.\\)?src\\server\.js"?\s*$'
$observedCommand=$p.CommandLine.Replace('/','\').ToLowerInvariant()
if($observedCommand -match $commandPattern){$entryMode='absolute';$runtimeDirectoryVerified=$true}
elseif($observedCommand -match $relativePattern){$entryMode='relative';$runtimeDirectoryVerified=$false}
else{throw 'Unexpected Node entry/flags; stopped. Only the exact observed relative or approved absolute entry is allowed.'}
$script:Node=$p.ExecutablePath
$version=RunNode -Arguments @('--version')
if($version -notmatch '^v24\.'){throw 'Expected verified Node24 runtime.'}
$tasks=@(Get-ScheduledTask -TaskName $TaskName)
if($tasks.Count -ne 1 -or @($tasks[0].Actions).Count -ne 1){throw 'Expected one existing startup task/action.'}
$action=$tasks[0].Actions[0]
if([IO.Path]::GetFileName($action.Execute) -notin @('powershell.exe','pwsh.exe') -or -not $action.Arguments.Contains($Startup)){throw 'Existing startup task contract is not verified.'}
if(-not (Test-Path -LiteralPath $Startup -PathType Leaf)){throw 'Existing startup script missing.'}
$startupText=[IO.File]::ReadAllText($Startup)
$startupDeclaresRoot=$startupText.ToLowerInvariant().Contains($Root.ToLowerInvariant())
# Non-executing AST inspection: report static startup-directory evidence separately from process cwd.
$startupWorkingDirectoryMatches=$false
$parseTokens=$null;$parseErrors=$null
$startupAst=[System.Management.Automation.Language.Parser]::ParseInput($startupText,[ref]$parseTokens,[ref]$parseErrors)
if(-not $parseErrors){
 $assignments=@($startupAst.FindAll({param($n) $n -is [System.Management.Automation.Language.AssignmentStatementAst]},$true))
 function StaticPath($n,[int]$before){
  if($n -is [System.Management.Automation.Language.StringConstantExpressionAst]){return $n.Value}
  if($n -is [System.Management.Automation.Language.VariableExpressionAst]){
   $name=$n.VariablePath.UserPath
   $matches=@($assignments|Where-Object {$_.Left -is [System.Management.Automation.Language.VariableExpressionAst] -and $_.Left.VariablePath.UserPath -eq $name})
   if($matches.Count -eq 1 -and $matches[0].Extent.StartOffset -lt $before){
    $literal=$matches[0].Right.Extent.Text.Trim()
    if($literal.Length -ge 2 -and (($literal[0] -eq [char]39 -and $literal[-1] -eq [char]39) -or ($literal[0] -eq [char]34 -and $literal[-1] -eq [char]34)) -and $literal -notmatch '[`$]'){return $literal.Substring(1,$literal.Length-2)}
   }
  }
  return $null
 }
 $commands=@($startupAst.FindAll({param($n) $n -is [System.Management.Automation.Language.CommandAst]},$true))
 foreach($command in $commands){
  $elements=@($command.CommandElements);$name=$command.GetCommandName();$directory=$null
  if($name -in @('Set-Location','cd','chdir') -and $elements.Count -eq 2){$directory=StaticPath $elements[1] $command.Extent.StartOffset}
  if($name -in @('Set-Location','cd','chdir','Start-Process')){
   for($i=1;$i -lt $elements.Count-1;$i++){
    if($elements[$i] -is [System.Management.Automation.Language.CommandParameterAst] -and (($name -eq 'Start-Process' -and $elements[$i].ParameterName -eq 'WorkingDirectory') -or ($name -ne 'Start-Process' -and $elements[$i].ParameterName -in @('Path','LiteralPath')))){$directory=StaticPath $elements[$i+1] $command.Extent.StartOffset}
   }
  }
  if($directory -and $directory.TrimEnd('\') -eq $Root.TrimEnd('\')){$startupWorkingDirectoryMatches=$true}
 }
}
# A startup declaration is evidence, not an independent measurement of a running relative-entry process cwd.

$health=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4317/health' -TimeoutSec 5
if($health.StatusCode -ne 200 -or -not (($health.Content|ConvertFrom-Json).ok)){throw 'Existing API health failed.'}
$headers=@{'Origin'='https://nustanakritwithai.github.io';'Access-Control-Request-Method'='POST';'Access-Control-Request-Headers'='authorization,content-type,idempotency-key'}
$cors=Invoke-WebRequest -UseBasicParsing -Method Options -Uri 'http://127.0.0.1:4317/v1/city-save' -Headers $headers -TimeoutSec 5
if($cors.StatusCode -ne 204 -or $cors.Headers['Access-Control-Allow-Origin'] -ne $headers.Origin){throw 'Exact Pages CORS preflight is not accepted.'}
$allowed=($cors.Headers['Access-Control-Allow-Headers'] -join ',').ToLowerInvariant().Split(',')|ForEach-Object {$_.Trim()}
foreach($name in @('authorization','content-type','idempotency-key')){if($name -notin $allowed){throw 'Pages preflight is missing a required save header; review required.'}}
if(-not $ReportDirectory){$ReportDirectory=Join-Path $env:TEMP ('city-save-plan-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))}
if(Test-Path -LiteralPath $ReportDirectory){throw 'ReportDirectory already exists; use a fresh directory.'}
[void](New-Item -ItemType Directory -Path $ReportDirectory)
[void](RunNode -Arguments @((Join-Path $PSScriptRoot 'patch-plan.mjs'),'plan',$Root,$ReportDirectory))
[void](RunNode -Arguments @('--check',(Join-Path $ReportDirectory 'server.js')))
[void](RunNode -Arguments @('--check',(Join-Path $ReportDirectory 'pages-auth.js')))
$db=RunNode -Arguments @((Join-Path $PSScriptRoot 'database-preflight.mjs'),$Root)
$report=@{ok=$runtimeDirectoryVerified;checksPassed=$true;result=$(if($runtimeDirectoryVerified){'PLAN_OK'}else{'PLAN_REVIEW_REQUIRED'});planVersion=2;mode='PLAN_ONLY';runtimeEntryMode=$entryMode;runtimeDirectoryVerified=$runtimeDirectoryVerified;startupDeclaresRoot=$startupDeclaresRoot;startupWorkingDirectoryMatches=$startupWorkingDirectoryMatches;processCreation=[string]$p.CreationDate;root=$Root;node=$version;pid=[int]$p.ProcessId;task=$TaskName;taskPath=$tasks[0].TaskPath;startupHash=(HashFile $Startup);sourceHashes=$pinned;health=200;pagesPreflight=204;database=($db|ConvertFrom-Json);reportDirectory=$ReportDirectory}
$report|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $ReportDirectory 'preflight-report.json') -Encoding UTF8
if($runtimeDirectoryVerified){Write-Output 'PLAN_OK: no live source, schema, account or process changed.'}else{Write-Output 'PLAN_REVIEW_REQUIRED: relative entry detected; running process cwd is unverified. Read-only database/source diagnostics completed. No live source, schema, account or process changed.'}
$report|ConvertTo-Json -Depth 8
