import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const sha=raw=>createHash('sha256').update(raw).digest('hex');
export const MARKER='CITY_SERVER_SAVE_V1';
function once(source,pattern,replacement,label){let count=0;const result=source.replace(new RegExp(pattern.source,pattern.flags.includes('g')?pattern.flags:pattern.flags+'g'),(...args)=>{count++;return typeof replacement==='function'?replacement(...args):replacement;});if(count!==1)throw Error(`Expected exactly one ${label} anchor; found ${count}. No patch applied.`);return result;}
export function patchSources(server,pages){
 if(server.includes(MARKER)||pages.includes(MARKER))throw Error('Installation marker already present; verify installed manifest instead of repatching.');
 let next=once(server,/app\.use\(express\.json\(\{\s*limit:\s*(['"])32kb\1\s*\}\)\);/,`// ${MARKER}: only this authenticated router owns the larger save parser.\nconst citySaveDefaultJson = express.json({limit:'32kb'});\napp.use((req,res,next)=>req.path==='/v1/city-save'||req.path.startsWith('/v1/city-save/')?next():citySaveDefaultJson(req,res,next));`,'default JSON parser');
 next=once(next,/app\.use\((['"])\/v1\/market\1,\s*marketReadRouter\(\{\s*pool,\s*guest\s*\}\)\);/,match=>`// ${MARKER}: existing verified Guest and CSRF, independent of trading.\napp.use('/v1/city-save',serverCityRouter({Router:express.Router,json:express.json,service:createServerCityService(createServerCityPgStore({pool,tx})),guest,csrf}));\n${match}`,'market router mount');
 next=`import {createServerCityService} from './city-saves/service.mjs';\nimport {createServerCityPgStore} from './city-saves/pg-store.mjs';\nimport {serverCityRouter} from './city-saves/router.mjs';\n${next}`;
 // Restrict the edit to this exact function and preserve every existing branch.
 const patchedPages=once(pages,/export function pagesBearerAllowed\(req\)\{([\s\S]*?)\n\}/,whole=>{
  const guard=/if\(req\.get\((['"])origin\1\)!==PAGES_ORIGIN\)return false;/i.exec(whole);
  const extraction=/const path=req\.originalUrl\.split\((['"])\?\1\)\[0\];/.exec(whole);
  if(!guard||!extraction||guard.index>extraction.index)throw Error('Exact Pages-origin guard must precede path extraction; refusing auth change.');
  return once(whole,/const path=req\.originalUrl\.split\((['"])\?\1\)\[0\];/,match=>`${match}\n  // ${MARKER}: exact owner city-save endpoints only; origin/token checks unchanged.\n  if(req.method==='GET'&&/^\\/v1\\/city-save(?:\\/archives(?:\\/[a-f0-9]{64})?)?$/.test(path))return true;\n  if(req.method==='POST'&&/^\\/v1\\/city-save(?:\\/archives)?$/.test(path))return true;`,'Pages path extraction');
 },'Pages bearer allowlist');
 return {server:next,pages:patchedPages};
}
const args=process.argv.slice(2);
if(args[0]==='plan'){
 const root=path.resolve(args[1]),out=path.resolve(args[2]);
 const server=fs.readFileSync(path.join(root,'src/server.js'),'utf8'),pages=fs.readFileSync(path.join(root,'src/pages-auth.js'),'utf8');
 const candidate=patchSources(server,pages);fs.mkdirSync(out,{recursive:true});
 fs.writeFileSync(path.join(out,'server.js'),candidate.server);fs.writeFileSync(path.join(out,'pages-auth.js'),candidate.pages);
 const files=['src/server.js','src/pages-auth.js','src/db.js','package.json'];
 const hashes=Object.fromEntries(files.map(p=>[p,sha(fs.readFileSync(path.join(root,p)))]));
 const plan={version:1,root,original:hashes,candidate:{'src/server.js':sha(candidate.server),'src/pages-auth.js':sha(candidate.pages)}};
 fs.writeFileSync(path.join(out,'source-plan.json'),JSON.stringify(plan,null,2));console.log(JSON.stringify({ok:true,original:hashes,candidate:plan.candidate}));
}
