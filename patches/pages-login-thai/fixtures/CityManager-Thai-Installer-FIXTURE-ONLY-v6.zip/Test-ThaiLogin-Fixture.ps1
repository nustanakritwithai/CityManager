# Synthetic only: no live startup, listener, task, service, DB, or account reads.
$ErrorActionPreference='Stop'
$old=$env:CM_THAI_FIXTURE_ONLY
try{
 $env:CM_THAI_FIXTURE_ONLY='1';. (Join-Path $PSScriptRoot 'Install-ThaiLogin.ps1')
 $rootLiteral="'"+$Root+"'";$nodeLiteral="'"+$Node+"'"
 $good='$root = '+$rootLiteral+"`n"+'$node = '+$nodeLiteral+"`n"+'$pg = ''C:\Program Files\PostgreSQL\16\bin\pg_ctl.exe''' + "`n" + '$ready = ''C:\Program Files\PostgreSQL\16\bin\pg_isready.exe''' + "`n" + 'function PgReady { & $ready -h 127.0.0.1 -p 55432 -t 2 2>&1 | Out-Null; return ($LASTEXITCODE -eq 0) }' + "`n" + 'if($state.code -eq 3 -and -not $dbStarted) { $cmd="& $pg -D $data -o ''''-p 55432 -h 127.0.0.1'''' -w start"; Start-Process -FilePath ''powershell.exe'' -ArgumentList @(''-NoProfile'',''-NonInteractive'',''-EncodedCommand'',$encoded) }' + "`n" + "try { `$api=Start-Process -FilePath `$node -ArgumentList 'src/server.js' -WorkingDirectory `$root -WindowStyle Hidden -PassThru -ErrorAction Stop } catch { }"
 AssertStartupText $good
 function MustFail([scriptblock]$f){$failed=$false;try{& $f}catch{$failed=$true};if(-not $failed){throw 'Expected a fail-closed rejection.'}}
 MustFail {AssertPgSafe};$AllowConditionalPostgresStart=$true;AssertPgSafe;$AllowConditionalPostgresStart=$false
 MustFail {AssertStartupText ($good.Replace($rootLiteral,"'C:\wrong'"))}
 MustFail {AssertStartupText ($good.Replace("'src/server.js'","'src/other.js'"))}
 MustFail {AssertStartupText ($good.Replace('127.0.0.1 -p 55432 -t 2','127.0.0.1 -p 1234 -t 2'))}
 MustFail {AssertStartupText ($good.Replace('state.code -eq 3','state.code -eq 4'))}
 MustFail {AssertStartupText ($good+"`n"+'$root = '+$rootLiteral)}
 function Get-NetTCPConnection {throw 'synthetic provider failure'}
 MustFail {Listeners}
 Remove-Item Function:Get-NetTCPConnection
 # Verify process exit, not merely listener disappearance, with synthetic CIM values.
 $script:fixtureDate=[DateTime]::SpecifyKind([DateTime]::Parse('2026-01-01T00:00:00Z'),[DateTimeKind]::Utc);$expectedProcess=@{Pid=42;Created=([DateTimeOffset]$script:fixtureDate).UtcDateTime.Ticks};$script:queries=0;$script:reuse=$false
 function TaskReady {}
 function Listeners {}
 function Start-Sleep {}
 function Get-CimInstance {param($ClassName,$Filter,$ErrorAction);$script:queries++;if($script:reuse){return [pscustomobject]@{CreationDate=$script:fixtureDate.AddSeconds(1)}};if($script:queries -eq 1){return [pscustomobject]@{CreationDate=$script:fixtureDate}}}
 WaitStopped $expectedProcess;if($script:queries -lt 2){throw 'Process exit was not awaited.'};$script:reuse=$true;MustFail {WaitStopped $expectedProcess}
 Remove-Item Function:Get-CimInstance;Remove-Item Function:Start-Sleep
 # Synthetic fixture uses its own test-only directory creator; live code uses a restricted Administrators/SYSTEM DACL.
 function PrivateDirectory([string]$Path){if(Test-Path -LiteralPath $Path){throw 'fixture collision'};[void](New-Item -ItemType Directory -Path $Path)}
 $dir=Join-Path ([IO.Path]::GetTempPath()) ('CMThaiFixture-'+[Guid]::NewGuid().ToString('N'));[void](New-Item -ItemType Directory -Path $dir)
 try{$a=Join-Path $dir 'old';$b=Join-Path $dir 'new';[IO.File]::WriteAllText($a,'old');[IO.File]::WriteAllText($b,'new');$acl=(Get-Acl -LiteralPath $a).Sddl;$oldHash=HashFile $a;$newHash=HashFile $b;$script:AtomicBackups=@();AtomicReplace $b $a $oldHash $newHash $acl;if((HashFile $a) -ne $newHash -or $script:AtomicBackups.Count -ne 1 -or (HashFile $script:AtomicBackups[0]) -ne $oldHash){throw 'Atomic fixture or retained backup failed.'};MustFail {AtomicReplace $b $a $oldHash $newHash $acl}}
 finally{Remove-Item -LiteralPath $dir -Recurse -Force}
 # The transaction itself is exercised against temporary synthetic files and mocked OS functions.
 $script:atomicOriginal=(Get-Command AtomicReplace).ScriptBlock
 function TaskContract([string]$h){if($script:drift -eq 'task'){throw 'synthetic task drift'}}
 function TaskReady {}
 function GuardedFiles([string]$h){if($script:drift -eq 'guard'){throw 'synthetic guard drift'}}
 function AssertPgSafe {}
 function SameRuntime($v){if($script:drift -eq 'pid'){throw 'synthetic PID drift'}}
 function Health {}
 function Listeners {if($script:queryFail){throw 'synthetic provider failure'};if($script:listener){[pscustomobject]@{LocalPort=4317}}}
 function Runtime {return @{Pid=2;Created=101;CommandHash='fixture'}}
 function WaitStopped($v){if($script:failure -eq 'stuck-before-change'){throw 'synthetic old process still alive'}}
 function StopApi($v,[string]$h,[string]$a){$script:stops++;$script:listener=$false;if($script:failure -eq 'stuck-before-change'){throw 'synthetic stop timeout'}}
 function StartApi([string]$h,[string]$a){$script:starts++;$script:StartedAt=100;if($script:failure -eq 'late-start' -and $h -ne $OriginalStartup){$script:listener=$false;$script:failure='none';throw 'synthetic ambiguous startup'};$script:listener=$true;if($script:failure -eq 'after-start' -and $h -ne $OriginalStartup){$script:failure='none';throw 'synthetic startup failure'}}
 function AtomicReplace([string]$from,[string]$to,[string]$oldHash,[string]$newHash,[string]$acl){
  & $script:atomicOriginal $from $to $oldHash $newHash $acl
  if(($script:failure -eq 'after-first' -and $to -eq $module -and $newHash -eq $patch.source.output) -or ($script:failure -eq 'after-second' -and $to -eq $Startup -and $newHash -eq $patch.guard.output)){$script:failure='none';throw 'synthetic replacement failure'}
 }
 foreach($scenario in @('after-first','after-second','after-start','late-start','stuck-before-change','pid','task','guard','module')){
  $case=Join-Path ([IO.Path]::GetTempPath()) ('CMThaiTxn-'+[Guid]::NewGuid().ToString('N'));[void](New-Item -ItemType Directory -Path $case);$stage=Join-Path $case 'stage';$backup=Join-Path $case 'backup';[void](New-Item -ItemType Directory -Path $stage);[void](New-Item -ItemType Directory -Path $backup)
  try{
   $module=Join-Path $case 'module';$Startup=Join-Path $case 'startup';[IO.File]::WriteAllText($module,'module-original');[IO.File]::WriteAllText($Startup,'startup-original');[IO.File]::WriteAllText((Join-Path $stage 'pages-auth.js'),'module-candidate');[IO.File]::WriteAllText((Join-Path $stage 'startup.ps1'),'startup-candidate');Copy-Item $module (Join-Path $backup 'pages-auth.js');Copy-Item $Startup (Join-Path $backup 'startup.ps1')
   $OriginalModule=HashFile $module;$OriginalStartup=HashFile $Startup;$moduleAcl=(Get-Acl -LiteralPath $module).Sddl;$startupAcl=(Get-Acl -LiteralPath $Startup).Sddl
   $patch=[pscustomobject]@{source=[pscustomobject]@{output=(HashFile (Join-Path $stage 'pages-auth.js'))};guard=[pscustomobject]@{output=(HashFile (Join-Path $stage 'startup.ps1'))}};$runtime=@{Pid=1;Created=1;CommandHash='fixture'}
   $script:stops=0;$script:starts=0;$script:listener=$true;$script:queryFail=$false;$script:failure=$scenario;$script:drift=$scenario
   if($scenario -eq 'module'){[IO.File]::WriteAllText($module,'external-change')}
   MustFail {InvokeTransaction}
   if($scenario -eq 'module'){if((Get-Content $module -Raw) -cne 'external-change'){throw 'Unrecognized module was overwritten.'}}elseif($scenario -eq 'late-start'){if((HashFile $module) -ne $patch.source.output -or (HashFile $Startup) -ne $patch.guard.output -or $script:starts -ne 1){throw 'Ambiguous-start rollback did not stop safely.'}}elseif((HashFile $module) -ne $OriginalModule){throw ("Module not restored: "+$scenario)}
   if($scenario -ne 'late-start' -and (HashFile $Startup) -ne $OriginalStartup){throw ("Startup not restored: "+$scenario)}
   if($scenario -in @('pid','task','guard','module') -and $script:stops -ne 0){throw ("Unexpected stop on drift: "+$scenario)}
   if($scenario -eq 'stuck-before-change' -and $script:starts -ne 0){throw 'Restarted while old synthetic PID was still alive.'}
  }finally{Remove-Item -LiteralPath $case -Recurse -Force}
 }
 Write-Output 'TRANSACTION FIXTURE PASS: after-first/second/start failures, ambiguous late start, and PID/task/guard/module drift; synthetic files and mocked OS only.'
 Write-Output 'FIXTURE PASS: parser, literal launch checks, rejection and isolated atomic replacement. No live paths inspected.'
}finally{$env:CM_THAI_FIXTURE_ONLY=$old}
