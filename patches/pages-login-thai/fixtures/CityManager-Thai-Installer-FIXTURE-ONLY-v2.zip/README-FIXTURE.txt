REVIEW CANDIDATE - DO NOT RUN INSTALLER ON PRODUCTION YET

This bundle contains public Thai UI candidate d468b38, a locally reviewed Node byte-patcher, a PowerShell draft with Plan and Apply hard-disabled, and synthetic tests. Even the separate unmodified draft fails closed if the actual startup's root assignment is not a direct literal match; no real startup contents are included. It does not establish the working directory of an already-running relative-entry process. Parent review and a Windows fixture test are required before any production instruction.

For the authorized existing VPS worker, ONLY in an isolated non-live directory and without elevation, run:
  node --test patch-login.test.mjs
  powershell.exe -NoProfile -NonInteractive -File .\Test-ThaiLogin-Fixture.ps1

The fixture test imports functions with a no-live-action gate and touches only a uniquely named temp directory. It does not read startup, listener, task, service, database, or account data. Return full test output and failure messages, not credentials. Do NOT run Install-ThaiLogin.ps1 -Mode Plan or Apply as part of this fixture request.
