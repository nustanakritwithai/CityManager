# DRAFT: DO NOT RUN. Root binding/task action checks remain pending user preflight.
[CmdletBinding()]
param([ValidateSet('Plan','Apply')][string]$Mode='Plan', [string]$ApprovedModuleHash='', [string]$ApprovedStartupHash='', [string]$ApprovedTaskHash='', [int]$ExpectedPid=0, [string]$ExpectedCreatedUtc='')
$ErrorActionPreference='Stop'
$Root='C:\Users\Administrator\Documents\Codex\2026-10-26\task-8\market-server-release-6269011'
$Startup='C:\ProgramData\CityManagerMarket\startup.ps1'
$Node='C:\Program Files\nodejs\node.exe'
$TaskName='CityManager-Market-Boot';$TaskPath='\';$Port=4317
$OriginalModule='b7a4638df16bd01914444b1bcd6a71dbfc11093201c011b56f6e057afa89464f'
$OriginalStartup='d6105be1cb4050bf5b46098d71688c344520f2cf2f150ba7a1dfec19a8926c81'
$CandidateHtml='8cb03d28d93eb5f3891e1c5b408804594a853f27afbfd3ba5ee8f958be592b7b'
$TaskExe='powershell.exe';$TaskWorkingDirectory='';$script:TaskActionHash=''
function HashFile([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function RequireHash([string]$Path,[string]$Hash){if((HashFile $Path) -ne $Hash){throw 'A pinned file differs; stopped.'}}
function NoReparse([string]$Path){$p=[IO.Path]::GetFullPath($Path);while($p){$item=Get-Item -LiteralPath $p -Force;if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Reparse point refused.'};$next=[IO.Path]::GetDirectoryName($p);if(-not $next -or $next -eq $p){break};$p=$next}}
function RunNode([string[]]$Arguments){$old=$ErrorActionPreference;try{$ErrorActionPreference='Continue';$out=@(& $Node @Arguments 2>&1);$code=$LASTEXITCODE}finally{$ErrorActionPreference=$old};if($code -ne 0){throw 'Node staging/check failed; no retry.'};return ($out -join "`n")}
function PrivateDirectory([string]$Path){
 if(Test-Path -LiteralPath $Path){throw 'Private directory collision.'}
 $security=New-Object Security.AccessControl.DirectorySecurity
 $security.SetAccessRuleProtection($true,$false)
 foreach($sid in @('S-1-5-18','S-1-5-32-544')){$who=[Security.Principal.SecurityIdentifier]::new($sid);$rule=[Security.AccessControl.FileSystemAccessRule]::new($who,[Security.AccessControl.FileSystemRights]::FullControl,([Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit),[Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow);$security.AddAccessRule($rule)}
 [void][IO.Directory]::CreateDirectory($Path,$security)
}
function AssertStartupText([string]$Text){
 $tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseInput($Text,[ref]$tokens,[ref]$errors);if($errors.Count){throw 'Startup parse failed.'}
 foreach($pair in @(@('root',$Root),@('node',$Node),@('pg','C:\Program Files\PostgreSQL\16\bin\pg_ctl.exe'),@('ready','C:\Program Files\PostgreSQL\16\bin\pg_isready.exe'))){
  $name=$pair[0];$expected=$pair[1];$assignments=@($ast.FindAll({param($x) $x -is [Management.Automation.Language.AssignmentStatementAst] -and $x.Left -is [Management.Automation.Language.VariableExpressionAst] -and $x.Left.VariablePath.UserPath -ieq $name},$true))
  if($assignments.Count -ne 1 -or $assignments[0].Operator -ne [Management.Automation.Language.TokenKind]::Equals){throw 'Startup assignment count or operator differs.'}
  $right=$assignments[0].Right.Extent.Text.Trim();if($right -cne ("'"+$expected+"'") -and $right -cne ('"'+$expected+'"')){throw 'Startup literal root or node differs.'}
 }
 $starts=@($ast.FindAll({param($x) $x -is [Management.Automation.Language.CommandAst] -and $x.GetCommandName() -ieq 'Start-Process' -and $x.Extent.Text -match '(?i)-FilePath\s+\$node\b'},$true))
 $pattern="(?is)^Start-Process\s+-FilePath\s+\`$node\s+-ArgumentList\s+'src/server\.js'\s+-WorkingDirectory\s+\`$root\s+-WindowStyle\s+Hidden\s+-PassThru\s+-ErrorAction\s+Stop$"
 if($starts.Count -ne 1 -or $starts[0].Extent.Text.Trim() -notmatch $pattern){throw 'Startup Node launch contract differs.'}
 # These structural checks supplement, not replace, the pinned full startup hash.
 $pgReady=@($ast.FindAll({param($x) $x -is [Management.Automation.Language.FunctionDefinitionAst] -and $x.Name -ieq 'PgReady'},$true))
 if($pgReady.Count -ne 1 -or $pgReady[0].Body.Extent.Text -notmatch '(?is)&\s*\$ready\s+-h\s+127\.0\.0\.1\s+-p\s+55432\s+-t\s+2' -or $pgReady[0].Body.Extent.Text -notmatch '(?is)\$LASTEXITCODE\s+-eq\s+0'){throw 'PostgreSQL readiness contract differs.'}
 if($Text -notmatch '(?is)\$state\.code\s+-eq\s+3\s+-and\s+-not\s+\$dbStarted' -or $Text -notmatch '(?is)-p\s+55432\s+-h\s+127\.0\.0\.1.*?-w\s+start' -or $Text -notmatch '(?is)Start-Process\s+-FilePath\s+''powershell\.exe''\s+-ArgumentList\s+@\(''-NoProfile'',''-NonInteractive'',''-EncodedCommand'',\s*\$encoded\)'){throw 'Conditional PostgreSQL start contract differs.'}
}
function StartupBinding {AssertStartupText ([IO.File]::ReadAllText($Startup))}
function TaskActionHash([string]$exe,[string]$argumentsText,[string]$work){$b=[Text.Encoding]::UTF8.GetBytes($exe+[char]0+$argumentsText+[char]0+$work);return [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($b)).Replace('-','').ToLowerInvariant()}
function TaskContract([string]$ExpectedStartupHash){
 RequireHash $Startup $ExpectedStartupHash
 $t=@(Get-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath);if($t.Count -ne 1 -or @($t[0].Actions).Count -ne 1){throw 'Unexpected task.'}
 $a=$t[0].Actions[0];$work=[string]$a.WorkingDirectory
 $pattern='^\s*(?:(?:-NoProfile|-NoLogo|-NonInteractive)\s+|-ExecutionPolicy\s+(?:Bypass|RemoteSigned|AllSigned|Restricted|Unrestricted)\s+|-WindowStyle\s+(?:Hidden|Normal|Minimized|Maximized)\s+)*-File\s+"?'+[regex]::Escape($Startup)+'"?\s*$'
 if($a.Execute -cne $TaskExe -or $work -cne $TaskWorkingDirectory -or $a.Arguments -notmatch $pattern){throw 'Task action differs.'}
 $hash=TaskActionHash $a.Execute $a.Arguments $work
 if($script:TaskActionHash -and $hash -ne $script:TaskActionHash){throw 'Task action drift.'};$script:TaskActionHash=$hash
}
function Listeners {@(Get-NetTCPConnection -State Listen -ErrorAction Stop | Where-Object {$_.LocalPort -eq $Port})}
function Runtime {
 $listeners=@(Listeners);$ids=@($listeners|Select-Object -ExpandProperty OwningProcess -Unique)
 if($ids.Count -ne 1 -or @($listeners|Where-Object {$_.LocalAddress -notin @('127.0.0.1','::1')}).Count){throw 'Expected sole loopback listener.'}
 $p=Get-CimInstance Win32_Process -Filter "ProcessId=$($ids[0])";if(-not $p -or $p.ExecutablePath -ne $Node){throw 'Unexpected process executable.'}
 $exe='(?:'+[regex]::Escape($Node)+'|node(?:\.exe)?)';$entry='(?:'+[regex]::Escape((Join-Path $Root 'src\server.js'))+'|(?:\.\\)?src\\server\.js)'
 if($p.CommandLine.Replace('/','\') -notmatch ('^\s*"?'+$exe+'"?\s+"?'+$entry+'"?\s*$')){throw 'Unexpected process entry or arguments.'}
 $cmdhash=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($p.CommandLine))).Replace('-','')
 return @{Pid=[int]$p.ProcessId;Created=([DateTimeOffset]$p.CreationDate).UtcDateTime.Ticks;CommandHash=$cmdhash}
}
function Health {if((Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4317/health' -TimeoutSec 3).StatusCode -ne 200){throw 'Health check failed.'}}
function SameRuntime($Expected){$now=Runtime;if($now.Pid -ne $Expected.Pid -or $now.Created -ne $Expected.Created -or $now.CommandHash -ne $Expected.CommandHash){throw 'Runtime identity drift.'}}
function GuardedFiles([string]$AuthHash){
 $expected=@{
  'src\server.js'='b3283f1380486f4da84dc365e677f24c01398224f2aaebf5fe49ffa1dc4f2736';
  'src\startup-guard.js'='dec068bc47b2ce02162eb39a1f3948c82f2fd143ba4e02ab0e1e9ffea26d5b90';
  'src\pages-auth.js'=$AuthHash;
  'src\owner-pin-auth.js'='e32ee986286fe6684f8e07a05fa0efc1c3b520ae9dabb02a75e03e2911bb6078';
  'src\city-saves\service.mjs'='103a44ee505bc938f5a69994baaab5f2cd4372b7cf567b5bdc31163fd2f217d1';
  'src\city-saves\pg-store.mjs'='dede1d6560cc6d6a2468913e8dc5fffc6c369fc0981337e7c98f26e1466256b9';
  'src\city-saves\router.mjs'='2a54010ec3a984c61d9005d19a3830c44abf2e901fcf4dfca385a88d177f90e6'
 }
 foreach($name in $expected.Keys){$path=Join-Path $Root $name;NoReparse $path;if((HashFile $path) -ne $expected[$name]){throw ('Guarded source drift: '+$name)}}
}
function TaskReady {if((Get-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath).State -ne 'Ready'){throw 'Shared startup task is not Ready; refusing API-only action.'}}
function AssertPgSafe {
 # Fail-closed pending review of the actual pinned startup PostgreSQL readiness/start control flow.
 throw 'PostgreSQL readiness and no-start contract has not yet been independently verified.'
}
function StopApi($Expected,[string]$StartupHash,[string]$AuthHash){
 TaskContract $StartupHash;TaskReady;GuardedFiles $AuthHash;AssertPgSafe;SameRuntime $Expected
 $p=Get-CimInstance Win32_Process -Filter "ProcessId=$($Expected.Pid)";if(-not $p -or ([DateTimeOffset]$p.CreationDate).UtcDateTime.Ticks -ne $Expected.Created){throw 'PID changed; refused stop.'}
 Stop-Process -Id $Expected.Pid -ErrorAction Stop
 WaitStopped $Expected
}
function WaitStopped($Expected){
 for($i=0;$i -lt 30;$i++){TaskReady;$current=Get-CimInstance Win32_Process -Filter "ProcessId=$($Expected.Pid)" -ErrorAction Stop;if($current -and ([DateTimeOffset]$current.CreationDate).UtcDateTime.Ticks -ne $Expected.Created){throw 'PID reused; quiescence refused.'};if(-not $current -and @(Listeners).Count -eq 0){return};Start-Sleep -Milliseconds 200};throw 'Verified API process/listener did not quiesce.'
}
function StartApi([string]$StartupHash,[string]$AuthHash){
 TaskContract $StartupHash;TaskReady;GuardedFiles $AuthHash;AssertPgSafe
 if(@(Listeners).Count -ne 0){throw 'Port occupied; refused start.'}
 $script:StartedAt=[DateTimeOffset]::UtcNow.UtcDateTime.Ticks;Start-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -ErrorAction Stop
 for($i=0;$i -lt 60;$i++){try{Health;$p=Runtime;if($p.Created -lt $script:StartedAt){throw 'Unexpected old process.'};return}catch{Start-Sleep -Seconds 1}}
 throw 'API did not become healthy.'
}
function AtomicReplace([string]$From,[string]$To,[string]$OldHash,[string]$NewHash,[string]$ExpectedAcl){
 RequireHash $To $OldHash;RequireHash $From $NewHash
 if((Get-Acl -LiteralPath $To).Sddl -cne $ExpectedAcl){throw 'Destination ACL drift.'}
 $tmpdir=Join-Path (Split-Path $To -Parent) ('ThaiReplace-'+[Guid]::NewGuid().ToString('N'));PrivateDirectory $tmpdir
 $tmp=Join-Path $tmpdir 'replacement';$previous=Join-Path $tmpdir 'previous';if(Test-Path -LiteralPath $previous){throw 'Replacement backup collision.'}
 try{[IO.File]::Copy($From,$tmp,$false);RequireHash $tmp $NewHash;[IO.File]::Replace($tmp,$To,$previous);RequireHash $previous $OldHash;RequireHash $To $NewHash;if((Get-Acl -LiteralPath $To).Sddl -cne $ExpectedAcl){throw 'Destination ACL changed.'};$script:AtomicBackups+=@($previous)}catch{Write-Warning ('Private replacement directory retained for inspection: '+$tmpdir);throw}
}
function InvokeTransaction {
$stopAttempted=$false;$changed=$false;$script:StartedAt=0
try{
 RequireHash $module $OriginalModule;RequireHash $Startup $OriginalStartup;RequireHash (Join-Path $stage 'pages-auth.js') $patch.source.output;RequireHash (Join-Path $stage 'startup.ps1') $patch.guard.output;SameRuntime $runtime;TaskContract $OriginalStartup;TaskReady;GuardedFiles $OriginalModule;AssertPgSafe
 $stopAttempted=$true;StopApi $runtime $OriginalStartup $OriginalModule
 $changed=$true;AtomicReplace (Join-Path $stage 'pages-auth.js') $module $OriginalModule $patch.source.output $moduleAcl
 AtomicReplace (Join-Path $stage 'startup.ps1') $Startup $OriginalStartup $patch.guard.output $startupAcl
 StartApi $patch.guard.output $patch.source.output;RequireHash $module $patch.source.output;RequireHash $Startup $patch.guard.output;Health
 Write-Output ('INSTALLED: API health 200; module='+$patch.source.output+' startup='+$patch.guard.output+' private-backup='+$backup);foreach($path in $script:AtomicBackups){Write-Output ('PRIVATE_REPLACEMENT_BACKUP='+$path)}
}catch{
 $reason=$_.Exception.Message
 if($stopAttempted -and -not $changed){try{if(@(Listeners).Count -ne 0){SameRuntime $runtime;Health}else{WaitStopped $runtime;StartApi $OriginalStartup $OriginalModule};Write-Warning 'Live files unchanged; original API healthy.'}catch{Write-Warning 'Original API recovery requires manual review.'}}
 elseif($changed){try{
  $sh=HashFile $Startup;$mh=HashFile $module;if($sh -notin @($OriginalStartup,$patch.guard.output) -or $mh -notin @($OriginalModule,$patch.source.output)){throw 'Unexpected file drift; rollback refused.'}
  RequireHash (Join-Path $backup 'pages-auth.js') $OriginalModule;RequireHash (Join-Path $backup 'startup.ps1') $OriginalStartup;TaskContract $sh
  if(@(Listeners).Count -ne 0){$r=Runtime;if(-not $script:StartedAt -or $r.Created -lt $script:StartedAt){throw 'Unexpected listener; rollback stop refused.'};StopApi $r $sh $mh}else{if($script:StartedAt){throw 'Start attempted without listener; rollback refused pending process inspection.'};TaskReady}
  TaskReady;if(@(Listeners).Count -ne 0){throw 'Not quiescent; rollback refused.'}
  if($mh -ne $OriginalModule){AtomicReplace (Join-Path $backup 'pages-auth.js') $module $mh $OriginalModule $moduleAcl}
  if($sh -ne $OriginalStartup){AtomicReplace (Join-Path $backup 'startup.ps1') $Startup $sh $OriginalStartup $startupAcl}
  StartApi $OriginalStartup $OriginalModule;RequireHash $module $OriginalModule;RequireHash $Startup $OriginalStartup;Health;Write-Warning 'Original module and startup restored and API healthy.'
 }catch{Write-Warning ('Rollback refused or failed; preserve private backup for manual recovery: '+$backup)}}
 throw ('Install stopped: '+$reason)
}

}
if($env:CM_THAI_FIXTURE_ONLY -eq '1'){return}
throw 'FIXTURE-ONLY BUILD: Plan and Apply are disabled; do not use on a live system.'
# No mutation until the binding gate, hash checks, and Plan/Apply validation pass.
$module=Join-Path $Root 'src\pages-auth.js';$bundle=$PSScriptRoot
foreach($p in @($Root,(Join-Path $Root 'src'),$module,(Split-Path $Startup -Parent),$Startup,$Node,$bundle)){NoReparse $p}
RequireHash (Join-Path $bundle 'patch-login.mjs') '41a56ea1660f8b9250332d031814235cf976103dea1695799374c7c56ac82bd5'
RequireHash (Join-Path $bundle 'stage-login.mjs') '78cf08a92e2e93bd71e5003ae4d350d6829e5debc3e70ffd76da8e2f03ff76e4'
RequireHash (Join-Path $bundle 'login.html') '0b8c35db7acfc1dbacd69d5ecb4dba451415f4b48ff0a315ba5fc7d77c35c365'
RequireHash $module $OriginalModule;RequireHash $Startup $OriginalStartup;StartupBinding;TaskContract $OriginalStartup
if($ExpectedPid -le 0 -or -not $ExpectedCreatedUtc){throw 'Provide the exact read-only preflight PID and ISO creation time.'};$expectedTicks=([DateTimeOffset]::Parse($ExpectedCreatedUtc)).UtcDateTime.Ticks
$runtime=Runtime;if($runtime.Pid -ne $ExpectedPid -or $runtime.Created -ne $expectedTicks){throw 'Preflight process changed; obtain new review.'};Health
$stage=Join-Path (Split-Path $Startup -Parent) ('ThaiLogin-'+[Guid]::NewGuid().ToString('N'));PrivateDirectory $stage
$patch=RunNode -Arguments @((Join-Path $bundle 'stage-login.mjs'),$stage)|ConvertFrom-Json
if($patch.source.input -ne $OriginalModule -or $patch.source.candidateHtml -ne $CandidateHtml -or $patch.guard.input -ne $OriginalStartup -or $patch.guard.oldPin -ne $OriginalModule -or $patch.guard.newPin -ne $patch.source.output){throw 'Staging manifest mismatch.'}
RequireHash (Join-Path $stage 'pages-auth.js') $patch.source.output;RequireHash (Join-Path $stage 'startup.ps1') $patch.guard.output
[void](RunNode -Arguments @('--check',(Join-Path $stage 'pages-auth.js')))
$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile((Join-Path $stage 'startup.ps1'),[ref]$tokens,[ref]$errors);if($errors.Count){throw 'Staged startup parse failed.'}
Write-Output ('SOURCE_CANDIDATE_SHA256='+$patch.source.output);Write-Output ('STARTUP_CANDIDATE_SHA256='+$patch.guard.output);Write-Output ('TASK_ACTION_SHA256='+$script:TaskActionHash);Write-Output ('PRIVATE_STAGE='+$stage);Write-Output 'Relative process entry is operationally bound through reviewed startup/task contract; OS process working directory is not directly measured.'
if($Mode -eq 'Plan'){Write-Output 'PLAN ONLY: no live source, process, DB or service changes.';return}
if($ApprovedModuleHash -notmatch '^[a-fA-F0-9]{64}$' -or $ApprovedStartupHash -notmatch '^[a-fA-F0-9]{64}$' -or $ApprovedTaskHash -notmatch '^[a-fA-F0-9]{64}$' -or $ApprovedTaskHash.ToLowerInvariant() -ne $script:TaskActionHash -or $ApprovedModuleHash.ToLowerInvariant() -ne $patch.source.output -or $ApprovedStartupHash.ToLowerInvariant() -ne $patch.guard.output){throw 'Apply needs the exact independently reviewed Plan candidate and task hashes.'}
$moduleAcl=(Get-Acl -LiteralPath $module).Sddl;$startupAcl=(Get-Acl -LiteralPath $Startup).Sddl
$backup=Join-Path $stage 'backup';PrivateDirectory $backup
Copy-Item -LiteralPath $module -Destination (Join-Path $backup 'pages-auth.js');Copy-Item -LiteralPath $Startup -Destination (Join-Path $backup 'startup.ps1')
RequireHash (Join-Path $backup 'pages-auth.js') $OriginalModule;RequireHash (Join-Path $backup 'startup.ps1') $OriginalStartup
# Exercise atomic replacement on same volumes without touching live targets.
foreach($parent in @((Split-Path $module -Parent),(Split-Path $Startup -Parent))){$tmpdir=Join-Path $parent ('ThaiAtomicTest-'+[Guid]::NewGuid().ToString('N'));PrivateDirectory $tmpdir;try{$a=Join-Path $tmpdir 'a';$b=Join-Path $tmpdir 'b';[IO.File]::WriteAllText($a,'old');[IO.File]::WriteAllText($b,'new');$acl=(Get-Acl -LiteralPath $a).Sddl;AtomicReplace $b $a (HashFile $a) (HashFile $b) $acl}finally{Remove-Item -LiteralPath $tmpdir -Recurse -Force}}
$script:AtomicBackups=@()
InvokeTransaction
