// Stages reviewed HTML and one guard pin, never writes the live source or startup.
import fs from 'node:fs';import path from 'node:path';import {patchHtml,patchGuard,sha} from './patch-login.mjs';
const ROOT=String.raw`C:\Users\Administrator\Documents\Codex\2026-10-26\task-8\market-server-release-6269011`;
const STARTUP=String.raw`C:\ProgramData\CityManagerMarket\startup.ps1`;
const sourceHash='b7a4638df16bd01914444b1bcd6a71dbfc11093201c011b56f6e057afa89464f',startupHash='d6105be1cb4050bf5b46098d71688c344520f2cf2f150ba7a1dfec19a8926c81';
const oldHtmlLfHash='04d8cfce326bfd8fa2603ab1c4574a850daa52498f4cc3e465e46a3c6ccdf47a',candidateHash='8cb03d28d93eb5f3891e1c5b408804594a853f27afbfd3ba5ee8f958be592b7b';
const expectedEntries={
 'src\\server.js':'b3283f1380486f4da84dc365e677f24c01398224f2aaebf5fe49ffa1dc4f2736',
 'src\\startup-guard.js':'dec068bc47b2ce02162eb39a1f3948c82f2fd143ba4e02ab0e1e9ffea26d5b90',
 'src\\pages-auth.js':sourceHash,
 'src\\owner-pin-auth.js':'e32ee986286fe6684f8e07a05fa0efc1c3b520ae9dabb02a75e03e2911bb6078',
 'src\\city-saves\\service.mjs':'103a44ee505bc938f5a69994baaab5f2cd4372b7cf567b5bdc31163fd2f217d1',
 'src\\city-saves\\pg-store.mjs':'dede1d6560cc6d6a2468913e8dc5fffc6c369fc0981337e7c98f26e1466256b9',
 'src\\city-saves\\router.mjs':'2a54010ec3a984c61d9005d19a3830c44abf2e901fcf4dfca385a88d177f90e6'
};
try{
 const stage=process.argv[2];if(!stage||!path.isAbsolute(stage)||!fs.statSync(stage).isDirectory())throw Error('stage-directory');
 for(const [name,h] of Object.entries(expectedEntries)){if(sha(fs.readFileSync(path.join(ROOT,...name.split('\\'))))!==h)throw Error('guarded-source-drift');}
 const source=fs.readFileSync(path.join(ROOT,'src','pages-auth.js')),startup=fs.readFileSync(STARTUP),candidate=fs.readFileSync(new URL('./login.html',import.meta.url));
 const html=patchHtml(source,candidate,{sourceHash,oldHtmlLfHash,candidateHash});
 const guard=patchGuard(startup,{startupHash,expectedEntries,oldModuleHash:sourceHash,newModuleHash:html.manifest.output});
 fs.writeFileSync(path.join(stage,'pages-auth.js'),html.result,{flag:'wx'});fs.writeFileSync(path.join(stage,'startup.ps1'),guard.result,{flag:'wx'});
 console.log(JSON.stringify({source:html.manifest,guard:guard.manifest}));
}catch(e){console.error(JSON.stringify({validation:e.message}));process.exitCode=1}
