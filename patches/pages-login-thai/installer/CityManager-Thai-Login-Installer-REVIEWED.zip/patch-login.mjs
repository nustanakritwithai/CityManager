// Pure byte-preserving transformations. Does not start a service or touch live paths.
import {createHash} from 'node:crypto';
export const sha=b=>createHash('sha256').update(b).digest('hex');
const utf8=b=>{const s=b.toString('utf8');if(!Buffer.from(s,'utf8').equals(b))throw Error('invalid-utf8');return s};
const fail=s=>{throw Error(s)};
export function patchHtml(source,candidate,{sourceHash,oldHtmlLfHash,candidateHash}){
 if(sha(source)!==sourceHash)fail('source-hash-mismatch');
 const template=utf8(candidate).trimEnd(), body=Buffer.from(template,'utf8');
 if(sha(body)!==candidateHash)fail('candidate-hash-mismatch');
 if(template.includes('`')||template.includes('${')||template.includes('\\'))fail('unsafe-template');
 const prefix=Buffer.from('export const LOGIN_HTML=`'),suffix=Buffer.from('`;');
 const start=source.indexOf(prefix);if(start<0||source.indexOf(prefix,start+1)>=0)fail('declaration-count');
 const begin=start+prefix.length,end=source.indexOf(suffix,begin);if(end<0)fail('declaration-end');
 const old=source.subarray(begin,end),oldText=utf8(old);
 if(sha(Buffer.from(oldText.replace(/\r\n/g,'\n')))!==oldHtmlLfHash)fail('html-baseline-mismatch');
 const before=source.subarray(0,begin),after=source.subarray(end),result=Buffer.concat([before,body,after]);
 return {result,manifest:{input:sha(source),oldHtmlRaw:sha(old),oldHtmlLf:oldHtmlLfHash,candidateHtml:sha(body),output:sha(result),beforeBytes:before.length,beforeHash:sha(before),afterBytes:after.length,afterHash:sha(after)}};
}
export function patchGuard(startup,{startupHash,expectedEntries,oldModuleHash,newModuleHash}){
 if(sha(startup)!==startupHash)fail('startup-hash-mismatch');if(!/^[a-f0-9]{64}$/.test(newModuleHash))fail('new-hash-invalid');
 const text=utf8(startup),matches=[...text.matchAll(/\$guard\s*=\s*@\{([^}]*?)\}/g)];if(matches.length!==1)fail('guard-count');const m=matches[0];
 const re=/(['"])(src\\[^'"\r\n]+)\1\s*=\s*(['"])([a-fA-F0-9]{64})\3/g,entries=[...m[1].matchAll(re)],keys=Object.keys(expectedEntries);
 if(!keys.length||entries.length!==keys.length||m[1].replace(re,'').replace(/[;\s]/g,'')!=='')fail('guard-shape');
 const seen=new Set();let target=null;for(const e of entries){const key=e[2];if(seen.has(key)||!Object.hasOwn(expectedEntries,key)||expectedEntries[key]!==e[4].toLowerCase())fail('guard-entry-drift');seen.add(key);if(key==='src\\pages-auth.js')target=e}
 if(!target||target[4].toLowerCase()!==oldModuleHash)fail('guard-target-drift');
 // Change only the 64 ASCII bytes of the one pin, preserving casing convention.
 const bodyStart=m.index+m[0].indexOf('{')+1,hashCharIndex=bodyStart+target.index+target[0].lastIndexOf(target[4]);
 const byteIndex=Buffer.byteLength(text.slice(0,hashCharIndex),'utf8'),oldBytes=Buffer.from(target[4]),before=startup.subarray(0,byteIndex),after=startup.subarray(byteIndex+64);
 if(!startup.subarray(byteIndex,byteIndex+64).equals(oldBytes))fail('guard-byte-offset');
 const replacement=target[4]===target[4].toUpperCase()?newModuleHash.toUpperCase():newModuleHash;
 const result=Buffer.concat([before,Buffer.from(replacement,'ascii'),after]);
 return {result,manifest:{input:sha(startup),output:sha(result),beforeBytes:before.length,beforeHash:sha(before),afterBytes:after.length,afterHash:sha(after),oldPin:oldModuleHash,newPin:newModuleHash}};
}
