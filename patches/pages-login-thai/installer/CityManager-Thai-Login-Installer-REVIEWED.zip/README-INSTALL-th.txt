CityManager — ตัวติดตั้งหน้าบัญชีภาษาไทย (ผู้ใช้เป็นผู้รัน)

แพ็กเกจนี้เปลี่ยนเฉพาะ LOGIN_HTML ใน pages-auth.js และค่า SHA-256 ของไฟล์นั้นหนึ่งรายการใน startup.ps1 เท่านั้น ไม่แก้ฐานข้อมูล รหัสผ่าน สิทธิ์ หรือ CSP สคริปต์จะหยุดเฉพาะ API PID ที่ตรวจยืนยันแล้ว ไม่สั่ง Stop-ScheduledTask และไม่สั่งหยุด PostgreSQL งาน startup เดิมอาจเริ่ม PostgreSQL ตัวเดิมหากพบว่าหยุดอยู่ ซึ่งผู้ใช้อนุญาตตามเงื่อนไขแล้ว

ต้องรันใน PowerShell ของผู้ดูแลจากโฟลเดอร์ที่แตก ZIP และตรวจ SHA-256 ของ ZIP ก่อน เริ่มด้วย Plan เท่านั้น โดยใช้ PID และเวลา creation จาก preflight ที่ยังเป็นปัจจุบัน ตัวอย่างจาก preflight ที่ให้ไว้ (ถ้าเปลี่ยน สคริปต์จะหยุด):

  powershell.exe -NoProfile -File .\Install-ThaiLogin.ps1 -Mode Plan -ExpectedPid 11664 -ExpectedCreatedUtc '2026-11-02T01:04:01.8196600+07:00'

Plan ตรวจ source/startup hashes, 7 guard entries, root/node/launcher, task action, listener/PID และ health พร้อมสร้าง candidate ในโฟลเดอร์ส่วนตัว โดยไม่หยุด API และไม่แก้ไฟล์ที่ใช้งาน ส่งกลับเฉพาะ SOURCE_CANDIDATE_SHA256, STARTUP_CANDIDATE_SHA256 และ TASK_ACTION_SHA256 เพื่อให้ผู้ประสานงานตรวจ อย่าส่งเนื้อหาไฟล์หรือข้อมูลลับ ถ้าขั้นใดไม่ผ่าน หยุดและแจ้งข้อความผิดพลาด ห้ามข้าม guard

หลังผู้ประสานงานตรวจค่า Plan และยืนยันให้ทำต่อเท่านั้น ให้ใช้ค่าจาก Plan ที่ตรวจแล้วแทนตัวพิมพ์ใหญ่ในคำสั่งนี้:

  powershell.exe -NoProfile -File .\Install-ThaiLogin.ps1 -Mode Apply -ExpectedPid 11664 -ExpectedCreatedUtc '2026-11-02T01:04:01.8196600+07:00' -ApprovedModuleHash MODULE_HASH -ApprovedStartupHash STARTUP_HASH -ApprovedTaskHash TASK_HASH -AllowConditionalPostgresStart

Apply ตรวจซ้ำก่อนหยุด และเก็บ backup ส่วนตัวไว้ ไม่ลบ backup หากตรวจพบไฟล์/PID/task เปลี่ยน หรือผลเริ่มระบบไม่แน่นอน สคริปต์จะหยุดเพื่อให้ตรวจด้วยมือ ไม่ฆ่า process ที่ไม่รู้จัก ระหว่าง Plan กับ Apply ห้ามมีการอัปเดตหรือรีสตาร์ตระบบจากงานอื่น

ข้อจำกัด: PID และ command line ประกอบกับสัญญา startup/task ที่ตรวจสอบเป็นหลักฐานเชิงปฏิบัติการ แต่ไม่ได้อ่าน working directory ของ process ที่กำลังทำงานโดยตรง ผลทดสอบ mock ไม่ใช่หลักฐาน backend จริง หรือการแก้ปัญหา recovery ข้ามแท็บ/รีโหลด PostgreSQL ไม่ได้รับอนุญาตให้หยุด และผลการตรวจ startup เป็นข้อความที่ผู้ใช้ส่งมาแบบคัดส่วน ไม่ใช่การรับรองทุกบรรทัด
